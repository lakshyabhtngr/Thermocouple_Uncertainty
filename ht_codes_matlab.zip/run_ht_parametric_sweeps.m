%% Parametric sweeps for the thermocouple probe design paper
% Runs the same MATLAB solver as run_ht_journal_analysis for selected
% off-the-shelf and industrial wire diameters and for Type E/J/K/N wires.
%
% Usage:
%   cd(fileparts(which('run_ht_parametric_sweeps.m')))
%   tbl = run_ht_parametric_sweeps();

function allData = run_ht_parametric_sweeps()
outDir = "../outputs/matlab_parametric";
if ~isfolder(outDir)
    mkdir(outDir);
end

diameters_um = [12 25 50 90 125 150 250 813];
tcTypes = {'E','J','K','N'};
allData = table();

for i = 1:numel(tcTypes)
    for j = 1:numel(diameters_um)
        r = run_ht_journal_analysis( ...
            "sweepMode","factorial", ...
            "diameter_um",diameters_um(j), ...
            "tcType",tcTypes{i}, ...
            "outDir",outDir, ...
            "makePlots",false, ...
            "runAutoencoder",false, ...
            "runRomOrderStudy",false, ...
            "runMonteCarlo",false);
        data = r.data;
        data.d_um = repmat(diameters_um(j), height(data), 1);
        data.Type(:) = tcTypes(i);
        allData = [allData; data]; %#ok<AGROW>
    end
end

writetable(allData, fullfile(outDir, "matlab_ht_diameter_type_design.csv"));
make_basic_plots(allData, outDir);
make_pc_order_study(allData, outDir);
end

function make_basic_plots(allData, outDir)
caseRows = allData(strcmp(allData.Stage,'TIT') & ismember(allData.L_over_d,[20 40]) & abs(allData.Mach-0.5)<1e-9 & allData.w==0.80 & allData.x==0.65, :);

figure('Color','w');
hold on;
diametersToPlot = [12 25 50 90 150 250 813];
for d = diametersToPlot
    rows = caseRows(strcmp(caseRows.Type,'N') & abs(caseRows.d_um-d)<1e-9 & caseRows.L_over_d==20, :);
    plot(rows.Tj_degF, rows.WorstCaseCorrected_degF, '-o', 'DisplayName', sprintf('%.0f um', d));
end
grid on; box on;
xlabel('TIT junction temperature, degF');
ylabel('U_{HT}, degF');
title('Effect of wire diameter, Type N, M=0.5, L/d=20');
legend('Location','northwest');
exportgraphics(gcf, fullfile(outDir, "matlab_diameter_effect_uncertainty.png"), "Resolution", 220);
close(gcf);

figure('Color','w');
tl = tiledlayout(1,2,"TileSpacing","compact");
for ld = [20 40]
    nexttile;
    hold on;
    for typ = {'E','J','K','N'}
        rows = caseRows(strcmp(caseRows.Type,typ{1}) & abs(caseRows.d_um-90)<1e-9 & caseRows.L_over_d==ld, :);
        plot(rows.Tj_degF, rows.WorstCaseCorrected_degF, '-o', 'DisplayName', ['Type ' typ{1}]);
    end
    grid on; box on;
    xlabel('TIT junction temperature, degF');
    ylabel('U_{HT}, degF');
    title(sprintf('d=90 um, M=0.5, L/d=%d', ld));
    legend('Location','northwest');
end
title(tl, 'Thermocouple type comparison: U_{HT} only');
exportgraphics(gcf, fullfile(outDir, "matlab_thermocouple_type_uncertainty.png"), "Resolution", 220);
close(gcf);
end

function make_pc_order_study(allData, outDir)
vars = ["Tj_degF","Mach","L_over_d","w","x","Pflow_psia","d_um","Re","Nu","hc","ks","Ti_degF"];
X = allData{:,vars};
types = {'E','J','K','N'};
oneHot = zeros(height(allData), numel(types));
for i = 1:numel(types)
    oneHot(:,i) = strcmp(string(allData.Type), types{i});
end
X = [X oneHot];
mu = mean(X,1);
sig = std(X,0,1);
sig(sig==0) = 1;
Z = (X - mu)./sig;
Y = allData.WorstCaseCorrected_degF;
Ylog = log10(Y + 1e-6);
rng(17);
idx = randperm(size(Z,1));
nTrain = floor(0.75*numel(idx));
train = idx(1:nTrain);
test = idx(nTrain+1:end);
[~,S,V] = svd(Z(train,:), "econ");
sing = diag(S);
explained = sing.^2/sum(sing.^2);
rows = [];
for nPC = 2:min(10,size(Z,2))
    Ztr = Z(train,:)*V(:,1:nPC);
    Zte = Z(test,:)*V(:,1:nPC);
    PhiTr = quadratic_features_local(Ztr);
    PhiTe = quadratic_features_local(Zte);
    beta = PhiTr\Ylog(train);
    predLog = PhiTe*beta;
    pred = 10.^predLog - 1e-6;
    rmseLog = sqrt(mean((predLog - Ylog(test)).^2));
    r2 = 1 - sum((Ylog(test)-predLog).^2)/sum((Ylog(test)-mean(Ylog(test))).^2);
    rel = abs(pred - Y(test))./max(Y(test),1e-6);
    rows = [rows; nPC, sum(explained(1:nPC)), rmseLog, r2, median(rel), quantile(rel,0.95)]; %#ok<AGROW>
end
romTable = array2table(rows, 'VariableNames', ...
    {'n_pc','variance_retained_train','rmse_log10','r2_log10','median_relative_error','p95_relative_error'});
writetable(romTable, fullfile(outDir, "matlab_parametric_pc_rom_order_sweep.csv"));

figure('Color','w');
plot(romTable.n_pc, romTable.rmse_log10, '-o', 'LineWidth', 1.8);
grid on; box on;
xlabel('Number of retained PCs');
ylabel('RMSE in log_{10}(U_{HT})');
title('Expanded PCA/SVD surrogate order study');
exportgraphics(gcf, fullfile(outDir, "matlab_parametric_pc_rom_order_sweep.png"), "Resolution", 220);
close(gcf);
end

function Phi = quadratic_features_local(Z)
n = size(Z,1);
cols = {ones(n,1)};
for i = 1:size(Z,2)
    cols{end+1} = Z(:,i); %#ok<AGROW>
end
for i = 1:size(Z,2)
    for j = i:size(Z,2)
        cols{end+1} = Z(:,i).*Z(:,j); %#ok<AGROW>
    end
end
Phi = [cols{:}];
end
