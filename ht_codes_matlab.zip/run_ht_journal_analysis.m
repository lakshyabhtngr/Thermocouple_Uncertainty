%% Thermocouple heat-transfer loss analysis for the Measurement journal paper
% This script reproduces the coauthor C solver, builds a design matrix,
% applies PCA/SVD, and optionally compares a shallow autoencoder surrogate.
%
% Usage from MATLAB:
%   cd(fileparts(which('run_ht_journal_analysis.m')))
%   results = run_ht_journal_analysis("sweepMode","factorial");
%   results90um = run_ht_journal_analysis("diameter_um",90,"tcType","N");
%   resultsK = run_ht_journal_analysis("diameter_um",90,"tcType","K","runMonteCarlo",true);
%
% sweepMode:
%   "legacy"    - matches ht.c: w and x are incremented together.
%   "factorial" - recommended for the paper: w and x varied independently.
%   "lhs"       - dense Latin-hypercube design for surrogate training.
%   "sobol"     - dense Sobol design when sobolset is available.
%   "cit_map"   - regular CIT grid for direct-vs-surrogate plotting.

function results = run_ht_journal_analysis(opts)
arguments
    opts.sweepMode (1,1) string {mustBeMember(opts.sweepMode,["legacy","factorial","lhs","sobol","cit_map"])} = "factorial"
    opts.outDir (1,1) string = "../outputs"
    opts.makePlots (1,1) logical = true
    opts.runAutoencoder (1,1) logical = true
    opts.runRomOrderStudy (1,1) logical = true
    opts.runMonteCarlo (1,1) logical = true
    opts.diameter_um (1,1) double = 812.8
    opts.tcType (1,1) char {mustBeMember(opts.tcType,{'E','J','K','N'})} = 'N'
    opts.nSamples (1,1) double {mustBeInteger,mustBePositive} = 8000
    opts.sampleSeed (1,1) double = 41
end

if ~isfolder(opts.outDir)
    mkdir(opts.outDir);
end

cfg = ht_default_config();
cfg.d_in = opts.diameter_um/25400;
cfg.Type = opts.tcType;
data = ht_build_design_table(cfg, opts.sweepMode, opts.nSamples, opts.sampleSeed);
writetable(data, fullfile(opts.outDir, "matlab_ht_design_table.csv"));

fprintf("Generated %d design points using %s sweep.\n", height(data), opts.sweepMode);

pcaResult = ht_svd_analysis(data, opts.outDir);
romOrder = [];
if opts.runRomOrderStudy
    romOrder = ht_pc_rom_order_study(data, opts.outDir);
end

aeResult = [];
if opts.runAutoencoder
    aeResult = ht_autoencoder_compare(data, opts.outDir);
end

mcResult = [];
if opts.runMonteCarlo
    mcResult = ht_monte_carlo_uncertainty(opts.outDir, 8000);
end

if opts.makePlots
    ht_plot_design_guidelines(data, pcaResult, opts.outDir);
end

results = struct();
results.config = cfg;
results.data = data;
results.pca = pcaResult;
results.romOrder = romOrder;
results.autoencoder = aeResult;
results.monteCarlo = mcResult;
end

function cfg = ht_default_config()
cfg.Rankine = 459.67;
cfg.StefanBoltzman = 4.76E-13;
cfg.Emissivity = 0.85;
cfg.U_Emissivity = 0.05;
cfg.AirDensityConstant = 2.7;
cfg.AirPrandtlNumber = 0.71;
cfg.U_AirPrandtlNumber = 0.50*cfg.AirPrandtlNumber/100;

cfg.stage.CIT.T_degF = [-80 -40 0 20 40 60 80 100 125 150];
cfg.stage.CIT.P_psia = 14.7;
cfg.stage.CDT.T_degF = [200 300 400 500 600 800 1000 1200 1350 1500];
cfg.stage.CDT.P_psia = 300.0;
cfg.stage.TIT.T_degF = [500 750 1000 1250 1500 1750 2000 2200 2400 2500];
cfg.stage.TIT.P_psia = 300.0;

cfg.Mach = [0.2 0.3 0.4 0.5 0.6 0.7];
cfg.L_over_d = [10 15 20 25 30 40];
cfg.w = [0.75 0.80 0.85];
cfg.x = [0.60 0.65 0.70];
cfg.d_in = 0.032;
cfg.Type = 'N';
cfg.Dir = 0;      % 0 parallel, 1 perpendicular
cfg.Shield = 1;   % 1 shielded, 0 unshielded
cfg.Tcell_degF = 50;
end

function data = ht_build_design_table(cfg, sweepMode, nSamples, sampleSeed)
stages = ["CIT","CDT","TIT"];
rows = {};
if sweepMode == "lhs" || sweepMode == "sobol"
    U = space_filling_unit(nSamples, 6, sampleSeed, sweepMode);
    for i = 1:nSamples
        s = stages(1 + min(2, floor(U(i,1)*numel(stages))));
        Tspan = cfg.stage.(s).T_degF;
        TjF = min(Tspan) + U(i,2)*(max(Tspan) - min(Tspan));
        P = cfg.stage.(s).P_psia;
        MnSet = 0.20 + U(i,3)*(0.80 - 0.20);
        Ld = 10.0 + U(i,4)*(50.0 - 10.0);
        w = 0.70 + U(i,5)*(0.90 - 0.70);
        x = 0.50 + U(i,6)*(0.80 - 0.50);
        rows(end+1,:) = ht_row_from_solver(cfg, char(s), P, TjF, MnSet, Ld, w, x); %#ok<AGROW>
    end
elseif sweepMode == "cit_map"
    s = "CIT";
    P = cfg.stage.CIT.P_psia;
    temps = -80:5:150;
    lds = 10:0.5:50;
    for TjF = temps
        for Ld = lds
            rows(end+1,:) = ht_row_from_solver(cfg, char(s), P, TjF, 0.5, Ld, 0.80, 0.65); %#ok<AGROW>
        end
    end
else
    for s = stages
        Tvals = cfg.stage.(s).T_degF;
        P = cfg.stage.(s).P_psia;
        for Ld = cfg.L_over_d
            if sweepMode == "legacy"
                wx = [cfg.w(:) cfg.x(:)];
            else
                [W,X] = ndgrid(cfg.w, cfg.x);
                wx = [W(:) X(:)];
            end
            for k = 1:size(wx,1)
                w = wx(k,1);
                x = wx(k,2);
                for TjF = Tvals
                    for MnSet = cfg.Mach
                        rows(end+1,:) = ht_row_from_solver(cfg, char(s), P, TjF, MnSet, Ld, w, x); %#ok<AGROW>
                    end
                end
            end
        end
    end
end
names = ["Stage","Type","Dir","Shield","d_in","d_um","L_over_d","w","x","Pflow_psia", ...
    "Mach","Tj_degF","Gamma","Vg_ft_s","Re","Nu","hc","ks","Ti_degF","Twall_degF","DTm_degR","ConductiveLoss_degF", ...
    "U_CL_degF","RadiativeLoss_degF","U_RL_degF","SignedTotalLoss_degF", ...
    "AbsoluteLoss_degF","RSS_Uncertainty_degF","WorstCaseCorrected_degF"];
data = cell2table(rows, 'VariableNames', cellstr(names));
end

function row = ht_row_from_solver(cfg, stageName, P, TjF, MnSet, Ld, w, x)
r = ht_solver_point(cfg, stageName, P, TjF, MnSet, Ld, w, x);
row = {stageName, cfg.Type, "Parallel", "On", cfg.d_in, cfg.d_in*25400, Ld, w, x, P, ...
    r.Mach, TjF, r.Gamma, r.Vg_ft_s, r.Re, r.Nu, r.hc, r.ks, r.Ti_degF, r.Twall_degF, r.DTm_degR, ...
    r.ConductiveLoss_degF, r.U_CL_degF, r.RadiativeLoss_degF, r.U_RL_degF, ...
    r.SignedTotalLoss_degF, r.AbsoluteLoss_degF, r.RSS_Uncertainty_degF, ...
    r.WorstCaseCorrected_degF};
end

function U = space_filling_unit(n, d, seed, method)
if method == "sobol" && exist('sobolset','file') == 2
    p = sobolset(d, 'Skip', 1024, 'Leap', 32);
    p = scramble(p, 'MatousekAffineOwen');
    U = net(p, n);
    return;
elseif method == "sobol"
    warning("sobolset was not found. Falling back to Latin-hypercube sampling.");
end
rng(seed);
U = zeros(n,d);
for j = 1:d
    U(:,j) = (randperm(n)' - rand(n,1))/n;
end
end

function r = ht_solver_point(cfg, ~, P, TjF, MnSet, Ld, w, x)
d_ft = cfg.d_in/12;
L_ft = Ld*d_ft;
TjR = TjF + cfg.Rankine;
TcellR = cfg.Tcell_degF + cfg.Rankine;

[Mach, gamma, Vg] = set_mach_number(TjR, MnSet);
rho = cfg.AirDensityConstant*P/TjR;
[mu, u_mu] = air_dynamic_viscosity(TjR);
[Nre, u_Nre] = reynolds_number(Vg, rho, d_ft, mu, u_mu);
[Nnu, u_Nnu] = nusselt_number(cfg.Dir, Nre, u_Nre);
[kf, u_kf] = air_thermo_conductivity(TjR);
[hc, u_hc] = convective_hc(kf, u_kf, Nnu, u_Nnu, d_ft);
[ks, u_ks] = wire_thermo_conductivity(TjR, cfg.Type);
DTm = conductive_delta_temp(TjR, w, TcellR);
[TiR, TwallR, u_Ti] = radiative_inner_temp(cfg, TjR, x, hc, u_hc, TcellR);
[CL, uCL] = conductive_loss(DTm, L_ft, d_ft, hc, ks, u_hc, u_ks);
[RL, uRL] = radiative_loss(cfg, TjR, TiR, hc, u_hc, u_Ti);

r.Mach = Mach;
r.Gamma = gamma;
r.Vg_ft_s = Vg;
r.Re = Nre;
r.Nu = Nnu;
r.hc = hc;
r.ks = ks;
r.Ti_degF = TiR - cfg.Rankine;
r.Twall_degF = TwallR - cfg.Rankine;
r.DTm_degR = DTm;
r.ConductiveLoss_degF = CL;
r.U_CL_degF = uCL;
r.RadiativeLoss_degF = RL;
r.U_RL_degF = uRL;
r.SignedTotalLoss_degF = CL + RL;
r.AbsoluteLoss_degF = abs(CL + RL);
r.RSS_Uncertainty_degF = hypot(uCL, uRL);
r.WorstCaseCorrected_degF = abs(CL) + uCL + abs(RL) + uRL;
end

function [Mn, g, Vg] = set_mach_number(TjR, MnSet)
g_C0 = 1.3930336; g_C1 = 6.81374E-5; g_C2 = -1.11831E-7; g_C3 = 3.16776E-11;
GravityConstat = 32.174; GasConstant = 1545.33; AirMolecularWeight = 28.9664;
g = g_C0 + TjR*(g_C1 + TjR*(g_C2 + TjR*g_C3));
Mn = MnSet;
Tsa = TjR/(1 + ((g-1)/2)*Mn*Mn);
Vel = sqrt(GravityConstat*GasConstant*g*Tsa/AirMolecularWeight);
Vg = Vel*Mn/2;
end

function [mu, u] = air_dynamic_viscosity(T)
DAV_C0 = 4.141794E-06; DAV_C1 = 1.709688E-08; DAV_C2 = -2.127130E-12;
TDAV_MIN = 559.67; TDAV_MAX = 2459.67; DAV_MIN = 1.274722E-05; DAV_MAX = 3.351389E-05; U_DAV = 0.50;
if T < TDAV_MIN
    mu = DAV_MIN;
elseif T > TDAV_MAX
    mu = DAV_MAX;
else
    mu = DAV_C0 + T*(DAV_C1 + T*DAV_C2);
end
u = U_DAV*mu/100;
end

function [kf, u] = air_thermo_conductivity(T)
ATC_C0 = 8.72732655E-07; ATC_C1 = 6.84123412E-09; ATC_C2 = -7.18448218E-13;
TATC_MIN = 559.67; TATC_MAX = 2459.67; ATC_MIN = 4.3639E-06; ATC_MAX = 1.3725E-05; U_ATC = 0.50;
if T < TATC_MIN
    kf = ATC_MIN;
elseif T > TATC_MAX
    kf = ATC_MAX;
else
    kf = ATC_C0 + T*(ATC_C1 + T*ATC_C2);
end
u = U_ATC*kf/100;
end

function [ks, u] = wire_thermo_conductivity(T, type)
switch type
    case 'N'
        C0 = 2.430266E-03; C1 = 8.074214E-07; C2 = -2.373496E-10;
        Tmin = 360.27; Tmax = 2160.27; kmin = 2.690349E-03; kmax = 3.066859E-03; U = 0.50;
    case 'K'
        C0 = 2.122727E-02; C1 = -1.472331E-05; C2 = 4.983878E-09;
        Tmin = 360.27; Tmax = 2160.27; kmin = 1.656978E-02; kmax = 1.267954E-02; U = 0.50;
    case 'J'
        C0 = 1.007941E-02; C1 = -4.839988E-06; C2 = 9.680179E-10;
        Tmin = 360.27; Tmax = 2160.27; kmin = 1.656978E-02; kmax = 4.141243E-03; U = 0.50;
    case 'E'
        C0 = 1.105492E-02; C1 = 5.928694E-06; C2 = 2.133430E-09;
        Tmin = 360.27; Tmax = 2160.27; kmin = 1.346776E-02; kmax = 2.864256E-02; U = 0.50;
    otherwise
        error("Unsupported thermocouple type.");
end
if T < Tmin
    ks = kmin;
elseif T > Tmax
    ks = kmax;
else
    ks = C0 + T*(C1 + T*C2);
end
u = U*ks/100;
end

function [Nre, u] = reynolds_number(Vg, rho, d, mu, u_mu)
Nre = rho*Vg*d/mu;
u = abs(-rho*Vg*d/(mu*mu))*u_mu;
end

function [Nnu, u] = nusselt_number(dir, Nre, ~)
if dir
    u = 0.06*sqrt(Nre);
    Nnu = 0.44*sqrt(Nre);
else
    u = 0.009*Nre^0.674;
    Nnu = 0.085*Nre^0.674;
end
end

function [hc, u] = convective_hc(kf, u_kf, Nnu, u_Nnu, d)
hc = Nnu*kf/d;
u = hypot((kf/d)*u_Nnu, (Nnu/d)*u_kf);
end

function DT = conductive_delta_temp(Tj, w, Tcell)
Tmount = Tj*w;
if Tmount < Tcell
    Tmount = Tcell;
end
DT = Tj - Tmount;
end

function [Ti, Twall, u] = radiative_inner_temp(cfg, Tj, x, hc, u_hc, Tcell)
Twall = x*Tj;
if ~cfg.Shield
    Ti = Twall; u = 0; return;
end
if Twall < Tcell
    Twall = Tcell;
end
if abs(Tj - Twall) < 0.1
    Twall = Tj - 1;
end
A = hc/(4.4*cfg.StefanBoltzman*cfg.Emissivity*(Tj - Twall));
Tin = linspace(max(Tj-400,0), Tj+400, 31)';
Teq = Tin.^3 + A*Tin - A*Tj;
p = polyfit(Teq, Tin, 1);
Ti = p(2);
Th1 = 1/(4.4*cfg.StefanBoltzman*cfg.Emissivity*Twall);
Th2 = -hc/(4.4*cfg.StefanBoltzman*cfg.Emissivity^2*Twall);
Th3 = (Tj - Ti)/(3*Ti^2 + A);
u = hypot(Th1*Th3*u_hc, Th3*Th2*cfg.U_Emissivity);
end

function [loss, u] = conductive_loss(DT, L, d, hc, ks, u_hc, u_ks)
X = sqrt(4*hc/(d*ks));
loss = DT/cosh(L*X);
ThXhc = (4/(d*ks))/(2*sqrt(4*hc/(d*ks)));
ThXks = (-4*hc/(d*ks*ks))/(2*sqrt(4*hc/(d*ks)));
ThX = -(DT*L*sinh(L*X))/(cosh(L*X)^2);
u = hypot(ThX*ThXhc*u_hc, ThX*ThXks*u_ks);
end

function [loss, u] = radiative_loss(cfg, T, Ti, hc, u_hc, u_Ti)
loss = cfg.StefanBoltzman*cfg.Emissivity*(T^4 - Ti^4)/hc;
ThTRTi = -4*(cfg.StefanBoltzman*cfg.Emissivity*Ti^3)/hc;
ThTRe = cfg.StefanBoltzman*(T^4 - Ti^4)/hc;
ThTRhc = -cfg.StefanBoltzman*cfg.Emissivity*(T^4 - Ti^4)/(hc^2);
u = sqrt((ThTRTi*u_Ti)^2 + (ThTRe*cfg.U_Emissivity)^2 + (ThTRhc*u_hc)^2);
end

function pcaResult = ht_svd_analysis(data, outDir)
vars = ["Tj_degF","Mach","L_over_d","w","x","Pflow_psia"];
X = data{:,vars};
Z = zscore(X);
[U,S,V] = svd(Z, "econ"); %#ok<ASGLU>
explained = diag(S).^2/sum(diag(S).^2);
loadings = array2table(V, 'VariableNames', cellstr("PC"+(1:numel(vars))), 'RowNames', cellstr(vars));

Y = log10(data.WorstCaseCorrected_degF + 1e-6);
A = [ones(size(Z,1),1), Z];
beta = A\Y;
Yhat = A*beta;
r2 = 1 - sum((Y-Yhat).^2)/sum((Y-mean(Y)).^2);

coef = table(cellstr(vars'), beta(2:end), abs(beta(2:end)), ...
    'VariableNames', {'Variable','LogLinearCoefficient','AbsCoefficient'});
coef = sortrows(coef, 'AbsCoefficient', 'descend');
writetable(coef, fullfile(outDir, "svd_loglinear_variable_ranking.csv"));
writetable(loadings, fullfile(outDir, "svd_feature_loadings.csv"), 'WriteRowNames', true);

pcaResult = struct("variables",vars,"explained",explained,"loadings",loadings, ...
    "logLinearCoefficients",coef,"logLinearR2",r2);
fprintf("SVD/log-linear R2 in log10 uncertainty space: %.3f\n", r2);
disp(coef);
end

function aeResult = ht_autoencoder_compare(data, outDir)
aeResult = struct("available",false);
if exist("trainAutoencoder","file") ~= 2 || exist("fitrgp","file") ~= 2
    warning("Deep Learning/Statistics Toolbox functions not found. Skipping autoencoder comparison.");
    return;
end
vars = ["Tj_degF","Mach","L_over_d","w","x","Pflow_psia"];
X = zscore(data{:,vars});
Y = log10(data.WorstCaseCorrected_degF + 1e-6);

rng(11);
idx = randperm(height(data));
nTrain = floor(0.75*numel(idx));
trainIdx = idx(1:nTrain);
testIdx = idx(nTrain+1:end);
train = false(height(data),1);
test = false(height(data),1);
train(trainIdx) = true;
test(testIdx) = true;

hiddenSize = 3;
autoenc = trainAutoencoder(X(train,:)', hiddenSize, ...
    'MaxEpochs', 300, 'L2WeightRegularization', 1e-4, ...
    'SparsityRegularization', 1, 'SparsityProportion', 0.1, ...
    'ScaleData', false, 'ShowProgressWindow', false);
Ztrain = encode(autoenc, X(train,:)')';
Ztest = encode(autoenc, X(test,:)')';
mdl = fitrgp(Ztrain, Y(train), 'Standardize', true);
pred = predict(mdl, Ztest);
rmse = sqrt(mean((pred - Y(test)).^2));
r2 = 1 - sum((Y(test)-pred).^2)/sum((Y(test)-mean(Y(test))).^2);
aeResult = struct("available",true,"hiddenSize",hiddenSize,"rmseLog10",rmse,"r2Log10",r2);
save(fullfile(outDir, "autoencoder_model.mat"), "autoenc", "mdl", "aeResult");
fprintf("Autoencoder latent surrogate: RMSE %.4f log10 degF, R2 %.3f.\n", rmse, r2);
end

function romResult = ht_pc_rom_order_study(data, outDir)
[X, Y] = ht_expanded_feature_matrix(data);
mu = mean(X,1);
sig = std(X,0,1);
sig(sig==0) = 1;
Z = (X - mu)./sig;
Ylog = log10(Y + 1e-6);
rng(17);
idx = randperm(size(Z,1));
nTrain = floor(0.75*numel(idx));
train = idx(1:nTrain);
test = idx(nTrain+1:end);
[~,S,V] = svd(Z(train,:), "econ");
sing = diag(S);
explained = sing.^2/sum(sing.^2);
rows = [];
for nPC = 2:min(10,size(Z,2))
    Ztr = Z(train,:)*V(:,1:nPC);
    Zte = Z(test,:)*V(:,1:nPC);
    PhiTr = quadratic_features_matlab(Ztr);
    PhiTe = quadratic_features_matlab(Zte);
    beta = PhiTr\Ylog(train);
    predLog = PhiTe*beta;
    pred = 10.^predLog - 1e-6;
    rmseLog = sqrt(mean((predLog - Ylog(test)).^2));
    r2 = 1 - sum((Ylog(test)-predLog).^2)/sum((Ylog(test)-mean(Ylog(test))).^2);
    rel = abs(pred - Y(test))./max(Y(test),1e-6);
    rows = [rows; nPC, sum(explained(1:nPC)), rmseLog, r2, median(rel), quantile(rel,0.95)]; %#ok<AGROW>
end
romTable = array2table(rows, 'VariableNames', ...
    {'n_pc','variance_retained_train','rmse_log10','r2_log10','median_relative_error','p95_relative_error'});
writetable(romTable, fullfile(outDir, "matlab_pc_rom_order_sweep.csv"));
romResult = romTable;

f = figure("Color","w","Position",[100 100 820 520]);
plot(romTable.n_pc, romTable.rmse_log10, "-o", "LineWidth", 1.8);
grid on; box on;
xlabel("Number of retained PCs");
ylabel("RMSE in log_{10}(U_{HT})");
title("PCA/SVD surrogate order study");
exportgraphics(f, fullfile(outDir, "matlab_pc_rom_order_sweep.png"), "Resolution", 220);
close(f);
end

function [X, Y, names] = ht_expanded_feature_matrix(data)
vars = ["Tj_degF","Mach","L_over_d","w","x","Pflow_psia","d_um","Re","Nu","hc","ks","Ti_degF"];
X = data{:,vars};
types = {'E','J','K','N'};
oneHot = zeros(height(data), numel(types));
for i = 1:numel(types)
    oneHot(:,i) = strcmp(string(data.Type), types{i});
end
X = [X oneHot];
Y = data.WorstCaseCorrected_degF;
names = [vars "Type_E" "Type_J" "Type_K" "Type_N"]; %#ok<NASGU>
end

function Phi = quadratic_features_matlab(Z)
n = size(Z,1);
cols = {ones(n,1)};
for i = 1:size(Z,2)
    cols{end+1} = Z(:,i); %#ok<AGROW>
end
for i = 1:size(Z,2)
    for j = i:size(Z,2)
        cols{end+1} = Z(:,i).*Z(:,j); %#ok<AGROW>
    end
end
Phi = [cols{:}];
end

function mcResult = ht_monte_carlo_uncertainty(outDir, n)
rng(42);
base = struct("Tj",1800.0,"Mach",0.5,"Ld",40.0,"d_um",90.0,"w",0.80,"x",0.65,"emissivity",0.85);
rrTable = [-0.0026 0.9998 2e-4 1e-4; -0.0020 0.9999 2e-4 1e-4; -0.0021 0.9999 2e-4 1e-4];
scenarios = {
    "all_sources", true, true, true, true;
    "recovery_ratio_only", true, false, false, false;
    "support_radiation_only", false, true, false, false;
    "geometry_flow_only", false, false, true, false;
    "material_properties_only", false, false, false, true};
scenarioSamples = cell(size(scenarios,1),1);
for s = 1:size(scenarios,1)
    scenarioSamples{s} = run_mc_scenario(base, rrTable, n, scenarios{s,2}, scenarios{s,3}, scenarios{s,4}, scenarios{s,5});
end
samples = scenarioSamples{1};
sampleTable = array2table(samples, 'VariableNames', ...
    {'Tj_degF','Mach','w','x','d_um','emissivity','mu_scale','kf_scale','ks_scale','recovery_ratio','correction_degF','U_HT_degF','estimated_T0_degF'});
writetable(sampleTable, fullfile(outDir, "matlab_monte_carlo_uncertainty_samples.csv"));
metrics = ["correction_degF";"U_HT_degF";"estimated_T0_degF"];
idx = [11 12 13];
summaryRows = {};
for k = 1:numel(metrics)
    vals = samples(:,idx(k));
    summaryRows(end+1,:) = {metrics(k)+"_mean", mean(vals)}; %#ok<AGROW>
    summaryRows(end+1,:) = {metrics(k)+"_p025", quantile(vals,0.025)}; %#ok<AGROW>
    summaryRows(end+1,:) = {metrics(k)+"_p50", quantile(vals,0.50)}; %#ok<AGROW>
    summaryRows(end+1,:) = {metrics(k)+"_p975", quantile(vals,0.975)}; %#ok<AGROW>
end
summary = cell2table(summaryRows, 'VariableNames', {'metric','value'});
writetable(summary, fullfile(outDir, "matlab_monte_carlo_uncertainty_summary.csv"));
contribRows = {};
for s = 1:size(scenarios,1)
    sName = scenarios{s,1};
    arr = scenarioSamples{s};
    for k = 1:numel(metrics)
        vals = arr(:,idx(k));
        p025 = quantile(vals,0.025);
        p50 = quantile(vals,0.50);
        p975 = quantile(vals,0.975);
        contribRows(end+1,:) = {sName, metrics(k), mean(vals), p025, p50, p975, p975-p025}; %#ok<AGROW>
    end
end
contrib = cell2table(contribRows, 'VariableNames', {'scenario','quantity','mean','p025','p50','p975','width95'});
writetable(contrib, fullfile(outDir, "matlab_monte_carlo_uncertainty_contributions.csv"));
mcResult = struct("samples",sampleTable,"summary",summary,"contributions",contrib);

f = figure("Color","w","Position",[100 100 860 520]);
histogram(samples(:,12), 42);
grid on; box on;
xlabel("U_{HT} heat-transfer allowance, degF");
ylabel("Count");
exportgraphics(f, fullfile(outDir, "matlab_monte_carlo_uncertainty_confidence.png"), "Resolution", 220);
close(f);
end

function samples = run_mc_scenario(base, rrTable, n, varyRecovery, varyBoundary, varyGeometry, varyMaterial)
samples = zeros(n,13);
for i = 1:n
    if varyGeometry
        Tj = base.Tj + 2.0*randn();
        Mach = max(0.05, base.Mach + 0.01*randn());
        d_um = max(10.0, base.d_um + 2.0*randn());
    else
        Tj = base.Tj; Mach = base.Mach; d_um = base.d_um;
    end
    if varyBoundary
        w = min(max(base.w + 0.035*randn(), 0.68), 0.92);
        x = min(max(base.x + 0.04*randn(), 0.50), 0.80);
        emissivity = min(max(base.emissivity + 0.05*randn(), 0.65), 0.98);
    else
        w = base.w; x = base.x; emissivity = base.emissivity;
    end
    if varyMaterial
        muScale = 1.0 + (0.005/1.96)*randn();
        kfScale = 1.0 + (0.005/1.96)*randn();
        ksScale = 1.0 + (0.08/1.96)*randn();
    else
        muScale = 1.0; kfScale = 1.0; ksScale = 1.0;
    end
    if varyRecovery
        row = rrTable(randi(size(rrTable,1)),:);
        a = row(1) + (row(3)/1.96)*randn();
        b = row(2) + (row(4)/1.96)*randn();
    else
        a = -0.0021; b = 0.9999;
    end
    recoveryRatio = min(max(a*Mach + b, 0.94), 1.01);
    [correction, UHT] = ht_solver_point_scaled(Tj, Mach, base.Ld, w, x, d_um, emissivity, muScale, kfScale, ksScale);
    estimatedT0 = (Tj + correction)/recoveryRatio;
    samples(i,:) = [Tj Mach w x d_um emissivity muScale kfScale ksScale recoveryRatio correction UHT estimatedT0];
end
end

function [signedLoss, worstCase] = ht_solver_point_scaled(TjF, MnSet, Ld, w, x, d_um, emissivity, muScale, kfScale, ksScale)
cfg = ht_default_config();
cfg.Type = 'K';
cfg.d_in = d_um/25400;
cfg.Emissivity = emissivity;
d_ft = cfg.d_in/12;
L_ft = Ld*d_ft;
TjR = TjF + cfg.Rankine;
TcellR = cfg.Tcell_degF + cfg.Rankine;
[~, ~, Vg] = set_mach_number(TjR, MnSet);
rho = cfg.AirDensityConstant*cfg.stage.TIT.P_psia/TjR;
[mu, u_mu] = air_dynamic_viscosity(TjR);
mu = mu*muScale; u_mu = u_mu*abs(muScale);
[Nre, u_Nre] = reynolds_number(Vg, rho, d_ft, mu, u_mu);
[Nnu, u_Nnu] = nusselt_number(cfg.Dir, Nre, u_Nre);
[kf, u_kf] = air_thermo_conductivity(TjR);
kf = kf*kfScale; u_kf = u_kf*abs(kfScale);
[hc, u_hc] = convective_hc(kf, u_kf, Nnu, u_Nnu, d_ft);
[ks, u_ks] = wire_thermo_conductivity(TjR, cfg.Type);
ks = ks*ksScale; u_ks = u_ks*abs(ksScale);
DTm = conductive_delta_temp(TjR, w, TcellR);
[TiR, ~, u_Ti] = radiative_inner_temp(cfg, TjR, x, hc, u_hc, TcellR);
[CL, uCL] = conductive_loss(DTm, L_ft, d_ft, hc, ks, u_hc, u_ks);
[RL, uRL] = radiative_loss(cfg, TjR, TiR, hc, u_hc, u_Ti);
signedLoss = CL + RL;
worstCase = abs(CL) + uCL + abs(RL) + uRL;
end

function ht_plot_design_guidelines(data, pcaResult, outDir)
stages = unique(string(data.Stage), "stable");
f = figure("Color","w","Position",[100 100 980 620]);
tiledlayout(1,2,"TileSpacing","compact");
nexttile;
hold on;
for s = stages'
    d = data(string(data.Stage)==s,:);
    scatter(d.Tj_degF, d.WorstCaseCorrected_degF, 18, d.Mach, "filled", ...
        "DisplayName", s);
end
set(gca,"YScale","log");
xlabel("Junction temperature, degF");
ylabel("Worst-case heat-transfer allowance, degF");
title("Heat-transfer uncertainty envelope");
grid on; box on; colorbar; legend("Location","northwest");

nexttile;
bar(100*pcaResult.explained(1:min(6,numel(pcaResult.explained))));
xlabel("Principal component");
ylabel("Variance explained, %");
title("SVD compression of design space");
grid on; box on;
exportgraphics(f, fullfile(outDir, "journal_design_guidelines.png"), "Resolution", 220);
close(f);
end
