%% SVD/PCA and autoencoder case study for the thermocouple uncertainty solver
%
% This routine is intended for discussion with an expert in SVD/PCA and
% autoencoders.  It first runs the MATLAB heat-transfer solver, then compares
% reduced-order models that use:
%
%   1. PCA/SVD scores followed by a quadratic regression model for log10(U_HT).
%   2. Shallow sparse and/or deeper fully connected nonlinear autoencoders
%      followed by the same quadratic regression model, when Deep Learning
%      Toolbox is available.
%
% The routine writes the model settings, feature definitions, loadings,
% explained variance, 5-vs-7 PC comparison, reconstruction errors and
% prediction errors to CSV/PNG files.
%
% Example:
%   cd matlab
%   report = run_ht_svd_autoencoder_case( ...
%       "tcType",'K', ...
%       "diameter_um",90, ...
%       "sweepMode","lhs", ...
%       "nSamples",8000, ...
%       "latentDims",[3 5 7 9], ...
%       "runDeepAutoencoder",true);
%
% If Deep Learning Toolbox is not installed, the script still runs the SVD
% analysis and records that the nonlinear autoencoder was skipped.

function report = run_ht_svd_autoencoder_case(opts)
arguments
    opts.sweepMode (1,1) string {mustBeMember(opts.sweepMode,["legacy","factorial","lhs","sobol","cit_map"])} = "factorial"
    opts.outDir (1,1) string = "../outputs/matlab_svd_autoencoder_case"
    opts.tcType (1,1) char {mustBeMember(opts.tcType,{'E','J','K','N'})} = 'K'
    opts.diameter_um (1,1) double = 90
    opts.nSamples (1,1) double {mustBeInteger,mustBePositive} = 8000
    opts.sampleSeed (1,1) double = 41
    opts.featureSet (1,1) string {mustBeMember(opts.featureSet,["design","expanded"])} = "expanded"
    opts.latentDims (1,:) double = [3 5 7 9]
    opts.testFraction (1,1) double {mustBeGreaterThan(opts.testFraction,0),mustBeLessThan(opts.testFraction,0.8)} = 0.25
    opts.randomSeed (1,1) double = 23
    opts.targetName (1,1) string {mustBeMember(opts.targetName,["WorstCaseCorrected_degF","RSS_Uncertainty_degF","AbsoluteLoss_degF"])} = "WorstCaseCorrected_degF"
    opts.runDeepAutoencoder (1,1) logical = true
    opts.autoencoderModels (1,:) string {mustBeMember(opts.autoencoderModels,["shallow_sparse","deep_fully_connected"])} = ["shallow_sparse","deep_fully_connected"]
    opts.autoencoderMaxEpochs (1,1) double = 500
    opts.deepHiddenUnits (1,:) double = [64 32]
    opts.initialLearnRate (1,1) double = 1e-3
    opts.miniBatchSize (1,1) double {mustBeInteger,mustBePositive} = 256
    opts.regressionRidge (1,1) double {mustBeNonnegative} = 1e-6
    opts.makePlots (1,1) logical = true
end

if ~isfolder(opts.outDir)
    mkdir(opts.outDir);
end

solver = run_ht_journal_analysis( ...
    'sweepMode',opts.sweepMode, ...
    'outDir',opts.outDir, ...
    'makePlots',false, ...
    'runAutoencoder',false, ...
    'runRomOrderStudy',false, ...
    'runMonteCarlo',false, ...
    'diameter_um',opts.diameter_um, ...
    'tcType',opts.tcType, ...
    'nSamples',opts.nSamples, ...
    'sampleSeed',opts.sampleSeed);

data = solver.data;
[Xraw, yRaw, featureNames] = build_case_feature_matrix(data, opts.featureSet, opts.targetName);
[Z, xMean, xStd] = standardize_columns(Xraw);
yLog = log10(yRaw + 1e-6);

rng(opts.randomSeed);
idx = randperm(size(Z,1));
nTest = max(1, round(opts.testFraction*numel(idx)));
testIdx = idx(1:nTest);
trainIdx = idx(nTest+1:end);

svdResult = run_svd_order_sweep(Z, yLog, yRaw, trainIdx, testIdx, featureNames, opts);
aeResult = run_autoencoder_order_sweep(Z, yLog, yRaw, trainIdx, testIdx, opts);

settings = make_settings_table(opts, featureNames, height(data), numel(trainIdx), numel(testIdx));
writetable(settings, fullfile(opts.outDir, "matlab_svd_autoencoder_case_settings.csv"));

if opts.makePlots
    plot_explained_variance(svdResult.explainedTable, opts.outDir);
    plot_order_metrics(svdResult.orderTable, aeResult.metricsTable, opts.outDir);
    plot_pc_scores(svdResult.scoresTrain, yLog(trainIdx), opts.outDir);
    plot_direct_surrogate_map(xMean, xStd, featureNames, trainIdx, Z, yLog, svdResult, aeResult, opts);
end

save(fullfile(opts.outDir, "matlab_svd_autoencoder_case_report.mat"), ...
    "opts", "data", "featureNames", "xMean", "xStd", "trainIdx", "testIdx", ...
    "svdResult", "aeResult");

report = struct();
report.settings = settings;
report.data = data;
report.featureNames = featureNames;
report.svd = svdResult;
report.autoencoder = aeResult;

fprintf("\nSVD/PCA and autoencoder case study complete.\n");
fprintf("Outputs written to: %s\n", opts.outDir);
disp(svdResult.orderTable);
if height(aeResult.metricsTable) > 0
    disp(aeResult.metricsTable);
else
    fprintf("Autoencoder metrics were not generated. See settings CSV for reason.\n");
end
end

function [X, y, featureNames] = build_case_feature_matrix(data, featureSet, targetName)
designVars = ["Tj_degF","Mach","L_over_d","w","x","Pflow_psia","d_um"];
expandedVars = ["Tj_degF","Mach","L_over_d","w","x","Pflow_psia","d_um", ...
    "Re","Nu","hc","ks","Ti_degF","Twall_degF","DTm_degR"];

if featureSet == "design"
    featureNames = designVars;
else
    featureNames = expandedVars;
end

X = data{:,featureNames};
y = data{:,targetName};
end

function [Z, mu, sig] = standardize_columns(X)
mu = mean(X,1);
sig = std(X,0,1);
sig(sig == 0) = 1;
Z = (X - mu)./sig;
end

function svdResult = run_svd_order_sweep(Z, yLog, yRaw, trainIdx, testIdx, featureNames, opts)
Ztrain = Z(trainIdx,:);
Ztest = Z(testIdx,:);
[~,S,V] = svd(Ztrain, "econ");
singularValues = diag(S);
explained = singularValues.^2/sum(singularValues.^2);
cumulative = cumsum(explained);

nMax = min([max(opts.latentDims), size(V,2), 12]);
allDims = unique([opts.latentDims 1:nMax]);
allDims = allDims(allDims >= 1 & allDims <= size(V,2));

rows = {};
coefRows = {};
for nPC = allDims
    scoresTrain = Ztrain*V(:,1:nPC);
    scoresTest = Ztest*V(:,1:nPC);
    [phiTrain, termNames] = quadratic_features(scoresTrain);
    phiTest = quadratic_features(scoresTest);
    beta = ridge_regression(phiTrain, yLog(trainIdx), opts.regressionRidge);
    predLog = phiTest*beta;
    pred = 10.^predLog - 1e-6;
    [rmseLog, r2Log, medianRel, p95Rel] = prediction_metrics(yLog(testIdx), yRaw(testIdx), predLog, pred);
    recTrain = scoresTrain*V(:,1:nPC)';
    recTest = scoresTest*V(:,1:nPC)';
    trainRecRmse = sqrt(mean((Ztrain(:) - recTrain(:)).^2));
    testRecRmse = sqrt(mean((Ztest(:) - recTest(:)).^2));
    rows(end+1,:) = {"pca_svd_quadratic", nPC, cumulative(nPC), rmseLog, r2Log, medianRel, p95Rel, trainRecRmse, testRecRmse}; %#ok<AGROW>
    if ismember(nPC, opts.latentDims)
        for k = 1:numel(beta)
            coefRows(end+1,:) = {nPC, termNames(k), beta(k)}; %#ok<AGROW>
        end
    end
end

orderTable = cell2table(rows, 'VariableNames', ...
    {'model','latent_dim','variance_retained','rmse_log10','r2_log10', ...
    'median_relative_error','p95_relative_error','train_reconstruction_rmse','test_reconstruction_rmse'});
writetable(orderTable, fullfile(opts.outDir, "matlab_svd_pc_order_metrics.csv"));

coefTable = cell2table(coefRows, 'VariableNames', {'latent_dim','term','coefficient_log10'});
writetable(coefTable, fullfile(opts.outDir, "matlab_svd_quadratic_rom_coefficients.csv"));

loadingTable = array2table(V, 'VariableNames', cellstr("PC"+(1:size(V,2))), 'RowNames', cellstr(featureNames));
writetable(loadingTable, fullfile(opts.outDir, "matlab_svd_feature_loadings.csv"), 'WriteRowNames', true);

explainedTable = table((1:numel(explained))', singularValues, explained, cumulative, ...
    'VariableNames', {'pc','singular_value','variance_fraction','cumulative_variance'});
writetable(explainedTable, fullfile(opts.outDir, "matlab_svd_explained_variance.csv"));

scoreTable = array2table(Z*V(:,1:min(7,size(V,2))), 'VariableNames', cellstr("PC"+(1:min(7,size(V,2)))));
scoreTable.Target_log10 = yLog;
writetable(scoreTable, fullfile(opts.outDir, "matlab_svd_scores_first7.csv"));

svdResult = struct();
svdResult.V = V;
svdResult.singularValues = singularValues;
svdResult.explained = explained;
svdResult.orderTable = orderTable;
svdResult.coefTable = coefTable;
svdResult.loadingTable = loadingTable;
svdResult.explainedTable = explainedTable;
svdResult.scoresTrain = Ztrain*V(:,1:min(3,size(V,2)));
bestPC = max(opts.latentDims(opts.latentDims <= size(V,2)));
bestScoresTrain = Ztrain*V(:,1:bestPC);
[bestPhiTrain, bestTermNames] = quadratic_features(bestScoresTrain);
svdResult.bestPC = bestPC;
svdResult.bestBeta = ridge_regression(bestPhiTrain, yLog(trainIdx), opts.regressionRidge);
svdResult.bestTermNames = bestTermNames;
end

function aeResult = run_autoencoder_order_sweep(Z, yLog, yRaw, trainIdx, testIdx, opts)
metricsTable = table();
reason = "";
autoencoders = struct();

if ~opts.runDeepAutoencoder
    reason = "Skipped because runDeepAutoencoder=false.";
elseif ~any(opts.autoencoderModels == "shallow_sparse") && ~any(opts.autoencoderModels == "deep_fully_connected")
    reason = "Skipped because no autoencoder model was requested.";
end

if reason ~= ""
    aeResult = struct("available",false,"reason",reason,"metricsTable",metricsTable,"autoencoders",autoencoders);
    write_autoencoder_note(opts.outDir, reason);
    return;
end

rows = {};
for latentDim = opts.latentDims
    latentDim = min(latentDim, size(Z,2));

    if any(opts.autoencoderModels == "shallow_sparse")
        try
            [encodedTrain, encodedTest, decodedTrain, decodedTest, modelObj] = ...
                fit_shallow_sparse_autoencoder(Z, trainIdx, testIdx, latentDim, opts);
            rows = append_autoencoder_metrics(rows, "shallow_sparse_autoencoder_quadratic", ...
                latentDim, encodedTrain, encodedTest, decodedTrain, decodedTest, Z, yLog, yRaw, trainIdx, testIdx, opts);
            autoencoders.(sprintf("shallow_sparse_latent_%d", latentDim)) = modelObj; %#ok<AGROW>
        catch err
            warning("Shallow sparse autoencoder latent dimension %d failed: %s", latentDim, err.message);
        end
    end

    if any(opts.autoencoderModels == "deep_fully_connected")
        try
            [encodedTrain, encodedTest, decodedTrain, decodedTest, modelObj] = ...
                fit_deep_fully_connected_autoencoder(Z, trainIdx, testIdx, latentDim, opts);
            rows = append_autoencoder_metrics(rows, "deep_fully_connected_autoencoder_quadratic", ...
                latentDim, encodedTrain, encodedTest, decodedTrain, decodedTest, Z, yLog, yRaw, trainIdx, testIdx, opts);
            autoencoders.(sprintf("deep_fc_latent_%d", latentDim)) = modelObj; %#ok<AGROW>
        catch err
            warning("Deep fully connected autoencoder latent dimension %d failed: %s", latentDim, err.message);
        end
    end
end

if isempty(rows)
    metricsTable = cell2table(cell(0,9), 'VariableNames', ...
        {'model','latent_dim','variance_retained','rmse_log10','r2_log10', ...
        'median_relative_error','p95_relative_error','train_reconstruction_rmse','test_reconstruction_rmse'});
else
    metricsTable = cell2table(rows, 'VariableNames', ...
        {'model','latent_dim','variance_retained','rmse_log10','r2_log10', ...
        'median_relative_error','p95_relative_error','train_reconstruction_rmse','test_reconstruction_rmse'});
end
writetable(metricsTable, fullfile(opts.outDir, "matlab_autoencoder_order_metrics.csv"));
save(fullfile(opts.outDir, "matlab_autoencoder_models.mat"), "autoencoders", "metricsTable");

if height(metricsTable) == 0
    reason = "trainAutoencoder was found, but all requested autoencoder fits failed. Check MATLAB warning messages.";
    write_autoencoder_note(opts.outDir, reason);
    aeResult = struct("available",false,"reason",reason,"metricsTable",metricsTable,"autoencoders",autoencoders);
else
    aeResult = struct("available",true,"reason","","metricsTable",metricsTable,"autoencoders",autoencoders);
end
end

function [encodedTrain, encodedTest, decodedTrain, decodedTest, autoenc] = fit_shallow_sparse_autoencoder(Z, trainIdx, testIdx, latentDim, opts)
if exist("trainAutoencoder","file") ~= 2
    error("trainAutoencoder was not found. Deep Learning Toolbox is required for shallow_sparse.");
end
autoenc = trainAutoencoder(Z(trainIdx,:)', latentDim, ...
    'MaxEpochs', opts.autoencoderMaxEpochs, ...
    'L2WeightRegularization', 1e-4, ...
    'SparsityRegularization', 1, ...
    'SparsityProportion', 0.10, ...
    'ScaleData', false, ...
    'ShowProgressWindow', false);
encodedTrain = encode(autoenc, Z(trainIdx,:)')';
encodedTest = encode(autoenc, Z(testIdx,:)')';
decodedTrain = predict(autoenc, Z(trainIdx,:)')';
decodedTest = predict(autoenc, Z(testIdx,:)')';
end

function [encodedTrain, encodedTest, decodedTrain, decodedTest, net] = fit_deep_fully_connected_autoencoder(Z, trainIdx, testIdx, latentDim, opts)
if exist("trainNetwork","file") ~= 2 || exist("featureInputLayer","file") ~= 2
    error("trainNetwork/featureInputLayer were not found. Deep Learning Toolbox is required for deep_fully_connected.");
end

nFeatures = size(Z,2);
hidden = opts.deepHiddenUnits(opts.deepHiddenUnits > latentDim);
if isempty(hidden)
    hidden = max([2*latentDim, nFeatures]);
end

layers = [ ...
    featureInputLayer(nFeatures, 'Normalization','none', 'Name','input')
    fullyConnectedLayer(hidden(1), 'Name','enc_fc1')
    reluLayer('Name','enc_relu1')];
for k = 2:numel(hidden)
    layers = [layers
        fullyConnectedLayer(hidden(k), 'Name',sprintf('enc_fc%d',k))
        reluLayer('Name',sprintf('enc_relu%d',k))]; %#ok<AGROW>
end
layers = [layers
    fullyConnectedLayer(latentDim, 'Name','latent')
    reluLayer('Name','latent_relu')];
for k = numel(hidden):-1:1
    layers = [layers
        fullyConnectedLayer(hidden(k), 'Name',sprintf('dec_fc%d',k))
        reluLayer('Name',sprintf('dec_relu%d',k))]; %#ok<AGROW>
end
layers = [layers
    fullyConnectedLayer(nFeatures, 'Name','reconstruction')
    regressionLayer('Name','mse')];

trainOptions = trainingOptions('adam', ...
    'MaxEpochs', opts.autoencoderMaxEpochs, ...
    'MiniBatchSize', opts.miniBatchSize, ...
    'InitialLearnRate', opts.initialLearnRate, ...
    'Shuffle','every-epoch', ...
    'Verbose',false, ...
    'Plots','none');

% For featureInputLayer, MATLAB expects observations in rows and features in
% columns.  The response has the same shape because the autoencoder reconstructs
% the standardized input vector.
net = trainNetwork(Z(trainIdx,:), Z(trainIdx,:), layers, trainOptions);
encodedTrain = activations(net, Z(trainIdx,:), 'latent', 'OutputAs','rows');
encodedTest = activations(net, Z(testIdx,:), 'latent', 'OutputAs','rows');
decodedTrain = predict(net, Z(trainIdx,:));
decodedTest = predict(net, Z(testIdx,:));
end

function rows = append_autoencoder_metrics(rows, modelName, latentDim, encodedTrain, encodedTest, decodedTrain, decodedTest, Z, yLog, yRaw, trainIdx, testIdx, opts)
[phiTrain, ~] = quadratic_features(encodedTrain);
phiTest = quadratic_features(encodedTest);
beta = ridge_regression(phiTrain, yLog(trainIdx), opts.regressionRidge);
predLog = phiTest*beta;
pred = 10.^predLog - 1e-6;
[rmseLog, r2Log, medianRel, p95Rel] = prediction_metrics(yLog(testIdx), yRaw(testIdx), predLog, pred);
trainResidual = Z(trainIdx,:) - decodedTrain;
testResidual = Z(testIdx,:) - decodedTest;
trainRecRmse = sqrt(mean(trainResidual(:).^2));
testRecRmse = sqrt(mean(testResidual(:).^2));
rows(end+1,:) = {modelName, latentDim, NaN, rmseLog, r2Log, medianRel, p95Rel, trainRecRmse, testRecRmse}; %#ok<AGROW>
end

function beta = ridge_regression(Phi, y, lambda)
if lambda <= 0
    beta = Phi\y;
    return;
end
penalty = eye(size(Phi,2));
penalty(1,1) = 0; % do not regularize the intercept
beta = (Phi'*Phi + lambda*penalty)\(Phi'*y);
end

function plot_direct_surrogate_map(xMean, xStd, featureNames, trainIdx, Z, yLog, svdResult, aeResult, opts)
try
    mapRun = run_ht_journal_analysis( ...
        'sweepMode',"cit_map", ...
        'outDir',opts.outDir, ...
        'makePlots',false, ...
        'runAutoencoder',false, ...
        'runRomOrderStudy',false, ...
        'runMonteCarlo',false, ...
        'diameter_um',opts.diameter_um, ...
        'tcType',opts.tcType, ...
        'nSamples',1, ...
        'sampleSeed',opts.sampleSeed);
catch err
    warning("Direct-vs-surrogate map was skipped because the direct map solve failed: %s", err.message);
    return;
end

mapData = mapRun.data;
Xmap = mapData{:,featureNames};
Zmap = (Xmap - xMean)./xStd;
direct = mapData.WorstCaseCorrected_degF;

scoresMap = Zmap*svdResult.V(:,1:svdResult.bestPC);
[phiMap, ~] = quadratic_features(scoresMap);
svdPred = 10.^(phiMap*svdResult.bestBeta) - 1e-6;

aePred = nan(size(direct));
aeLabel = "autoencoder unavailable";
if isstruct(aeResult) && isfield(aeResult,'metricsTable') && height(aeResult.metricsTable) > 0
    aeRows = aeResult.metricsTable;
    [~, bestIdx] = min(aeRows.rmse_log10);
    bestRow = aeRows(bestIdx,:);
    latentDim = bestRow.latent_dim;
    modelName = string(bestRow.model);
    try
        if contains(modelName, "shallow")
            modelObj = aeResult.autoencoders.(sprintf("shallow_sparse_latent_%d", latentDim));
        else
            modelObj = aeResult.autoencoders.(sprintf("deep_fc_latent_%d", latentDim));
        end
        latentTrain = encode_autoencoder_latent(modelObj, modelName, Z(trainIdx,:));
        latentMap = encode_autoencoder_latent(modelObj, modelName, Zmap);
        [phiTrain, ~] = quadratic_features(latentTrain);
        [phiAEMap, ~] = quadratic_features(latentMap);
        betaAE = ridge_regression(phiTrain, yLog(trainIdx), opts.regressionRidge);
        aePred = 10.^(phiAEMap*betaAE) - 1e-6;
        aeLabel = sprintf("%s, %d latent variables", strrep(modelName,"_"," "), latentDim);
    catch err
        warning("Autoencoder map prediction was skipped: %s", err.message);
    end
end

temps = unique(mapData.Tj_degF);
lds = unique(mapData.L_over_d);
[LDgrid, Tgrid] = meshgrid(lds, temps);
directM = reshape(direct, numel(lds), numel(temps))';
svdM = reshape(svdPred, numel(lds), numel(temps))';
aeM = reshape(aePred, numel(lds), numel(temps))';
errM = log10(max(abs(svdM - directM), 1e-6));
if all(isfinite(aeM(:)))
    errM = log10(max(abs(aeM - directM), 1e-6));
end

mapTable = table(mapData.Tj_degF, mapData.L_over_d, direct, svdPred, aePred, ...
    'VariableNames', {'Tj_degF','L_over_d','direct_UHT_degF','svd_UHT_degF','autoencoder_UHT_degF'});
writetable(mapTable, fullfile(opts.outDir, "matlab_direct_svd_autoencoder_map.csv"));

f = figure('Color','w','Position',[100 100 1120 840]);
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
nexttile;
contourf(LDgrid, Tgrid, log10(max(directM,1e-6)), 24, 'LineColor','none');
colorbar; grid on; box on;
xlabel('L/d'); ylabel('CIT junction temperature, degF');
title('Direct solver: log_{10}(U_{HT})');

nexttile;
contourf(LDgrid, Tgrid, log10(max(svdM,1e-6)), 24, 'LineColor','none');
colorbar; grid on; box on;
xlabel('L/d'); ylabel('CIT junction temperature, degF');
title(sprintf('PCA/SVD ROM: %d PCs', svdResult.bestPC));

nexttile;
if all(isfinite(aeM(:)))
    contourf(LDgrid, Tgrid, log10(max(aeM,1e-6)), 24, 'LineColor','none');
    title(char(aeLabel));
else
    text(0.1,0.5,'Autoencoder map unavailable','Units','normalized');
    title('Autoencoder ROM');
end
colorbar; grid on; box on;
xlabel('L/d'); ylabel('CIT junction temperature, degF');

nexttile;
contourf(LDgrid, Tgrid, errM, 24, 'LineColor','none');
colorbar; grid on; box on;
xlabel('L/d'); ylabel('CIT junction temperature, degF');
if all(isfinite(aeM(:)))
    title('Autoencoder absolute error: log_{10}(|\\Delta U_{HT}|)');
else
    title('SVD absolute error: log_{10}(|\\Delta U_{HT}|)');
end

exportgraphics(f, fullfile(opts.outDir, "matlab_direct_svd_autoencoder_map.png"), 'Resolution', 220);
close(f);
end

function latent = encode_autoencoder_latent(modelObj, modelName, Zinput)
if contains(modelName, "shallow")
    latent = encode(modelObj, Zinput')';
else
    latent = activations(modelObj, Zinput, 'latent', 'OutputAs','rows');
end
end

function [Phi, names] = quadratic_features(Z)
n = size(Z,1);
cols = {ones(n,1)};
names = "1";
for i = 1:size(Z,2)
    cols{end+1} = Z(:,i); %#ok<AGROW>
    names(end+1) = "z"+i; %#ok<AGROW>
end
for i = 1:size(Z,2)
    for j = i:size(Z,2)
        cols{end+1} = Z(:,i).*Z(:,j); %#ok<AGROW>
        names(end+1) = "z"+i+"*z"+j; %#ok<AGROW>
    end
end
Phi = [cols{:}];
end

function [rmseLog, r2Log, medianRel, p95Rel] = prediction_metrics(yLogTrue, yTrue, predLog, pred)
rmseLog = sqrt(mean((predLog - yLogTrue).^2));
r2Log = 1 - sum((yLogTrue - predLog).^2)/sum((yLogTrue - mean(yLogTrue)).^2);
rel = abs(pred - yTrue)./max(yTrue, 1e-6);
medianRel = median(rel);
p95Rel = quantile(rel, 0.95);
end

function settings = make_settings_table(opts, featureNames, nRows, nTrain, nTest)
rows = {
    "purpose", "Compare PCA/SVD ROM with shallow sparse autoencoder ROM";
    "solver", "MATLAB translation of the thermocouple heat-transfer solver";
    "thermocouple_type", string(opts.tcType);
    "diameter_um", string(opts.diameter_um);
    "sweep_mode", opts.sweepMode;
    "n_samples_requested", string(opts.nSamples);
    "sample_seed", string(opts.sampleSeed);
    "feature_set", opts.featureSet;
    "features", strjoin(featureNames, ", ");
    "target", opts.targetName;
    "target_transform", "log10(target + 1e-6)";
    "latent_dimensions", strjoin(string(opts.latentDims), ", ");
    "svd_model", "Scores from SVD of standardized training feature matrix, followed by quadratic ridge regression";
    "autoencoder_models", strjoin(opts.autoencoderModels, ", ");
    "shallow_autoencoder_model", "One-hidden-layer shallow sparse autoencoder trained on standardized features, followed by quadratic ridge regression";
    "deep_autoencoder_model", "Symmetric fully connected encoder-decoder trained with Adam on standardized features, followed by quadratic ridge regression";
    "quadratic_regression_ridge_lambda", string(opts.regressionRidge);
    "deep_hidden_units", strjoin(string(opts.deepHiddenUnits), ", ");
    "autoencoder_epochs", string(opts.autoencoderMaxEpochs);
    "autoencoder_initial_learning_rate", string(opts.initialLearnRate);
    "autoencoder_mini_batch_size", string(opts.miniBatchSize);
    "convolutional_recurrent_note", "Not used by default because the input matrix is tabular; CNN/RNN layers require a defensible spatial or sequential ordering of variables.";
    "rows_total", string(nRows);
    "rows_train", string(nTrain);
    "rows_test", string(nTest);
    "random_seed", string(opts.randomSeed)
    };
settings = cell2table(rows, 'VariableNames', {'item','value'});
end

function write_autoencoder_note(outDir, reason)
note = table({'autoencoder_status';'reason'}, {'not_run';char(reason)}, 'VariableNames', {'item','value'});
writetable(note, fullfile(outDir, "matlab_autoencoder_not_run.csv"));
end

function plot_explained_variance(explainedTable, outDir)
f = figure("Color","w","Position",[100 100 860 520]);
yyaxis left;
bar(explainedTable.pc, 100*explainedTable.variance_fraction);
ylabel("Variance per PC, %");
yyaxis right;
plot(explainedTable.pc, 100*explainedTable.cumulative_variance, "-o", "LineWidth", 1.8);
ylabel("Cumulative variance, %");
xlabel("Principal component");
grid on; box on;
title("PCA/SVD explained variance");
exportgraphics(f, fullfile(outDir, "matlab_svd_explained_variance.png"), "Resolution", 220);
close(f);
end

function plot_order_metrics(svdTable, aeTable, outDir)
f = figure("Color","w","Position",[100 100 900 560]);
hold on;
plot(svdTable.latent_dim, svdTable.rmse_log10, "-o", "LineWidth", 1.8, "DisplayName", "PCA/SVD quadratic ROM");
if height(aeTable) > 0
    models = unique(string(aeTable.model), "stable");
    markers = ["-s","-d","-^","-v"];
    for i = 1:numel(models)
        rows = aeTable(string(aeTable.model)==models(i),:);
        rows = sortrows(rows, 'latent_dim');
        plot(rows.latent_dim, rows.rmse_log10, markers(1 + mod(i-1,numel(markers))), ...
            "LineWidth", 1.8, "DisplayName", strrep(models(i), "_", " "));
    end
end
xline(5, "--", "5 PCs", "LabelVerticalAlignment","bottom");
xline(7, "--", "7 PCs", "LabelVerticalAlignment","bottom");
grid on; box on;
xlabel("Latent dimension");
ylabel("Test RMSE in log_{10}(U_{HT})");
legend("Location","northeast");
title("Reduced-order prediction error");
exportgraphics(f, fullfile(outDir, "matlab_svd_autoencoder_order_comparison.png"), "Resolution", 220);
close(f);
end

function plot_pc_scores(scoresTrain, yLogTrain, outDir)
if size(scoresTrain,2) < 2
    return;
end
f = figure("Color","w","Position",[100 100 760 620]);
scatter(scoresTrain(:,1), scoresTrain(:,2), 26, yLogTrain, "filled");
grid on; box on; colorbar;
xlabel("PC1 score");
ylabel("PC2 score");
title("Training data projected onto first two PCs");
exportgraphics(f, fullfile(outDir, "matlab_svd_pc1_pc2_scores.png"), "Resolution", 220);
close(f);
end
