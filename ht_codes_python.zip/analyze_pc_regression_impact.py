# -*- coding: utf-8 -*-
"""
Created on Tue Aug  4 16:58:20 2026

@author: laksh
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def analyze_pc_regression_impact(data, feature_set="expanded", target_name="WorstCaseCorrected_degF", n_components=5):
    """
    Performs Principal Component Regression (PCR) of the input variables against 
    the target temperature and projects the regression coefficients back to 
    the original standardized input space.
    """
    # 1. Define feature sets (matching the main script structure)
    design_vars = ["Tj_degF", "Mach", "L_over_d", "w", "x", "Pflow_psia", "d_um"]
    expanded_vars = [
        "Tj_degF", "Mach", "L_over_d", "w", "x", "Pflow_psia", "d_um",
        "Re", "Nu", "hc", "ks", "Ti_degF", "Twall_degF", "DTm_degR"
    ]
    
    feature_names = design_vars if feature_set == "design" else expanded_vars
    
    # 2. Extract input feature matrix X and target vector y
    X = data[feature_names].values
    y = data[target_name].values
    
    # 3. Standardize features (Z-score normalization)
    mu = np.mean(X, axis=0)
    std = np.std(X, axis=0, ddof=0)
    std[std == 0] = 1.0
    Z = (X - mu) / std
    
    # Transform y to log scale as performed in the original pipeline
    y_log = np.log10(y + 1e-6)
    
    # 4. Perform SVD / PCA on standardized input features Z
    # Z = U * S * V^T, where V contains the principal component loadings
    _, S, Vt = np.linalg.svd(Z, full_matrices=False)
    V = Vt.T  # Feature loadings matrix (n_features x n_components)
    
    # Retain selected number of principal components
    k = min(n_components, V.shape[1])
    V_k = V[:, :k]
    
    # Compute PC scores (projections of input features onto principal components)
    PC_scores = Z @ V_k
    
    # 5. Perform Linear Regression of y_log against PC Scores
    # Add intercept column
    Phi_PC = np.hstack([np.ones((PC_scores.shape[0], 1)), PC_scores])
    
    # Ordinary Least Squares (OLS) fit on PC scores
    gamma, _, _, _ = np.linalg.lstsq(Phi_PC, y_log, rcond=None)
    
    intercept = gamma[0]
    beta_PC = gamma[1:]  # Coefficients for each PC score
    
    # 6. Map PC Coefficients back to Original Standardized Input Variables
    # beta_Z = V_k * beta_PC
    beta_Z = V_k @ beta_PC
    
    # 7. Construct Summary DataFrames
    pc_names = [f"PC{i+1}" for i in range(k)]
    
    pc_impact_df = pd.DataFrame({
        'Principal Component': pc_names,
        'Singular Value': S[:k],
        'Explained Variance Ratio': (S[:k]**2) / np.sum(S**2),
        'Regression Coefficient (Gamma)': beta_PC
    })
    
    feature_impact_df = pd.DataFrame({
        'Feature': feature_names,
        'Mean': mu,
        'Std Dev': std,
        'Standardized Impact Coefficient (Beta_Z)': beta_Z,
        'Absolute Impact': np.abs(beta_Z)
    }).sort_values(by='Absolute Impact', ascending=False).reset_index(drop=True)
    
    # 8. Plot Impact of Standardized Variables on Final Temperature
    plt.figure(figsize=(10, 6))
    colors = ['crimson' if c < 0 else 'navy' for c in feature_impact_df['Standardized Impact Coefficient (Beta_Z)']]
    
    plt.barh(feature_impact_df['Feature'], feature_impact_df['Standardized Impact Coefficient (Beta_Z)'], color=colors)
    plt.axvline(0, color='black', linestyle='--', linewidth=0.8)
    plt.xlabel(f"Standardized Effect on Log10({target_name})")
    plt.ylabel("Input Features")
    plt.title(f"Principal Component Regression Impact Analysis ({k} PCs Retained)")
    plt.gca().invert_yaxis()  # Most impactful feature on top
    plt.grid(True, linestyle=':', alpha=0.6)
    plt.tight_layout()
    plt.show()
    
    return {
        'pc_metrics': pc_impact_df,
        'feature_impact': feature_impact_df,
        'intercept': intercept,
        'loadings': pd.DataFrame(V_k, index=feature_names, columns=pc_names)
    }


# ==============================================================================
# Example Usage Block (Integrating with original dataset output)
# ==============================================================================
if __name__ == "__main__":
    # Assuming 'solver_result' is returned from run_ht_svd_autoencoder_case()
    # or 'data' DataFrame is directly available:
    from main_script import run_ht_svd_autoencoder_case  # Adjust module import as needed

    # Run original analysis case to obtain data
    results = run_ht_svd_autoencoder_case(makePlots=False)
    data = results['data']

    # Execute PC Regression analysis using 5 Principal Components
    pcr_results = analyze_pc_regression_impact(
        data=data,
        feature_set="expanded",
        target_name="WorstCaseCorrected_degF",
        n_components=5
    )

    print("\n--- Principal Component Regression Coefficients ---")
    print(pcr_results['pc_metrics'])

    print("\n--- Relative Variable Impacts on Final Temperature ---")
    print(pcr_results['feature_impact'])