# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 21:17:43 2026

@author: laksh
"""

import os
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# PyTorch import with fallback handling
try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import TensorDataset, DataLoader
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

from ht_journal_analysis import run_ht_journal_analysis


# ==============================================================================
# Helper & Utility Functions
# ==============================================================================

def build_case_feature_matrix(data, feature_set="expanded", target_name="WorstCaseCorrected_degF"):
    """Extracts design or expanded features and the target variable from data."""
    design_vars = ["Tj_degF", "Mach", "L_over_d", "w", "x", "Pflow_psia", "d_um"]
    expanded_vars = [
        "Tj_degF", "Mach", "L_over_d", "w", "x", "Pflow_psia", "d_um",
        "Re", "Nu", "hc", "ks", "Ti_degF", "Twall_degF", "DTm_degR"
    ]
    
    feature_names = design_vars if feature_set == "design" else expanded_vars
    X = data[feature_names].values
    y = data[target_name].values
    return X, y, feature_names


def standardize_columns(X):
    """Z-score normalizes matrix columns."""
    mu = np.mean(X, axis=0)
    sig = np.std(X, axis=0, ddof=0)
    sig[sig == 0] = 1.0
    Z = (X - mu) / sig
    return Z, mu, sig


def quadratic_features(Z):
    """Generates polynomial features up to degree 2 (intercept, linear, interaction)."""
    n, p = Z.shape
    cols = [np.ones((n, 1))]
    names = ["1"]
    
    for i in range(p):
        cols.append(Z[:, i:i+1])
        names.append(f"z{i+1}")
        
    for i in range(p):
        for j in range(i, p):
            cols.append((Z[:, i] * Z[:, j])[:, np.newaxis])
            names.append(f"z{i+1}*z{j+1}")
            
    Phi = np.hstack(cols)
    return Phi, names


def ridge_regression(Phi, y, lambda_val=1e-6):
    """Fits linear/quadratic regression with L2 regularization (exempting intercept)."""
    if lambda_val <= 0:
        beta, _, _, _ = np.linalg.lstsq(Phi, y, rcond=None)
        return beta
    
    penalty = np.eye(Phi.shape[1])
    penalty[0, 0] = 0.0  # Do not regularize intercept
    beta = np.linalg.solve(Phi.T @ Phi + lambda_val * penalty, Phi.T @ y)
    return beta


def prediction_metrics(y_log_true, y_true, pred_log, pred):
    """Computes RMSE, R^2, median relative error, and 95th percentile error."""
    rmse_log = np.sqrt(np.mean((pred_log - y_log_true)**2))
    r2_log = 1.0 - np.sum((y_log_true - pred_log)**2) / np.sum((y_log_true - np.mean(y_log_true))**2)
    rel = np.abs(pred - y_true) / np.maximum(y_true, 1e-6)
    median_rel = np.median(rel)
    p95_rel = np.percentile(rel, 95)
    return rmse_log, r2_log, median_rel, p95_rel


def write_autoencoder_note(out_dir, reason):
    """Writes a note explaining why autoencoder analysis was skipped/failed."""
    note = pd.DataFrame([['autoencoder_status', 'not_run'], ['reason', str(reason)]], columns=['item', 'value'])
    note.to_csv(os.path.join(out_dir, "matlab_autoencoder_not_run.csv"), index=False)


# ==============================================================================
# SVD / PCA Sweep
# ==============================================================================

def run_svd_order_sweep(Z, yLog, yRaw, trainIdx, testIdx, featureNames, opts):
    """Performs SVD dimension reduction and fits quadratic ROMs across latent dimensions."""
    Ztrain, Ztest = Z[trainIdx], Z[testIdx]
    
    # SVD decomposition: Ztrain = U * S * Vt -> V = Vt.T
    _, S, Vt = np.linalg.svd(Ztrain, full_matrices=False)
    V = Vt.T
    singularValues = S
    explained = (S**2) / np.sum(S**2)
    cumulative = np.cumsum(explained)

    max_pcs = min(max(opts['latentDims']), V.shape[1], 12)
    all_dims = sorted(list(set(list(opts['latentDims']) + list(range(1, max_pcs + 1)))))
    all_dims = [d for d in all_dims if 1 <= d <= V.shape[1]]

    rows, coefRows = [], []
    for nPC in all_dims:
        scoresTrain = Ztrain @ V[:, :nPC]
        scoresTest = Ztest @ V[:, :nPC]
        
        phiTrain, termNames = quadratic_features(scoresTrain)
        phiTest, _ = quadratic_features(scoresTest)
        
        beta = ridge_regression(phiTrain, yLog[trainIdx], opts['regressionRidge'])
        predLog = phiTest @ beta
        pred = 10.0**predLog - 1e-6
        
        rmseLog, r2Log, medianRel, p95Rel = prediction_metrics(
            yLog[testIdx], yRaw[testIdx], predLog, pred
        )
        
        recTrain = scoresTrain @ V[:, :nPC].T
        recTest = scoresTest @ V[:, :nPC].T
        trainRecRmse = np.sqrt(np.mean((Ztrain - recTrain)**2))
        testRecRmse = np.sqrt(np.mean((Ztest - recTest)**2))
        
        rows.append([
            "pca_svd_quadratic", nPC, cumulative[nPC-1], rmseLog, r2Log,
            medianRel, p95Rel, trainRecRmse, testRecRmse
        ])
        
        if nPC in opts['latentDims']:
            for k in range(len(beta)):
                coefRows.append([nPC, termNames[k], beta[k]])

    orderTable = pd.DataFrame(rows, columns=[
        'model', 'latent_dim', 'variance_retained', 'rmse_log10', 'r2_log10',
        'median_relative_error', 'p95_relative_error',
        'train_reconstruction_rmse', 'test_reconstruction_rmse'
    ])
    orderTable.to_csv(os.path.join(opts['outDir'], "matlab_svd_pc_order_metrics.csv"), index=False)

    coefTable = pd.DataFrame(coefRows, columns=['latent_dim', 'term', 'coefficient_log10'])
    coefTable.to_csv(os.path.join(opts['outDir'], "matlab_svd_quadratic_rom_coefficients.csv"), index=False)

    loadingCols = [f"PC{i+1}" for i in range(V.shape[1])]
    loadingTable = pd.DataFrame(V, index=featureNames, columns=loadingCols)
    loadingTable.to_csv(os.path.join(opts['outDir'], "matlab_svd_feature_loadings.csv"))

    explainedTable = pd.DataFrame({
        'pc': np.arange(1, len(explained) + 1),
        'singular_value': singularValues,
        'variance_fraction': explained,
        'cumulative_variance': cumulative
    })
    explainedTable.to_csv(os.path.join(opts['outDir'], "matlab_svd_explained_variance.csv"), index=False)

    n_first = min(7, V.shape[1])
    scoreCols = [f"PC{i+1}" for i in range(n_first)]
    scoreTable = pd.DataFrame(Z @ V[:, :n_first], columns=scoreCols)
    scoreTable['Target_log10'] = yLog
    scoreTable.to_csv(os.path.join(opts['outDir'], "matlab_svd_scores_first7.csv"), index=False)

    bestPC = max([d for d in opts['latentDims'] if d <= V.shape[1]])
    bestScoresTrain = Ztrain @ V[:, :bestPC]
    bestPhiTrain, bestTermNames = quadratic_features(bestScoresTrain)
    bestBeta = ridge_regression(bestPhiTrain, yLog[trainIdx], opts['regressionRidge'])

    return {
        'V': V,
        'singularValues': singularValues,
        'explained': explained,
        'orderTable': orderTable,
        'coefTable': coefTable,
        'loadingTable': loadingTable,
        'explainedTable': explainedTable,
        'scoresTrain': Ztrain @ V[:, :min(3, V.shape[1])],
        'bestPC': bestPC,
        'bestBeta': bestBeta,
        'bestTermNames': bestTermNames
    }


# ==============================================================================
# PyTorch Autoencoder Models & Sweeps
# ==============================================================================

if TORCH_AVAILABLE:
    class ShallowSparseAutoencoder(nn.Module):
        def __init__(self, input_dim, latent_dim):
            super().__init__()
            self.encoder = nn.Linear(input_dim, latent_dim)
            self.decoder = nn.Linear(latent_dim, input_dim)

        def forward(self, x):
            encoded = torch.sigmoid(self.encoder(x))
            decoded = self.decoder(encoded)
            return encoded, decoded

    class DeepFullyConnectedAutoencoder(nn.Module):
        def __init__(self, input_dim, latent_dim, hidden_units):
            super().__init__()
            hidden = [h for h in hidden_units if h > latent_dim]
            if not hidden:
                hidden = [max(2 * latent_dim, input_dim)]

            enc_layers = []
            in_dim = input_dim
            for h in hidden:
                enc_layers.extend([nn.Linear(in_dim, h), nn.ReLU()])
                in_dim = h
            enc_layers.extend([nn.Linear(in_dim, latent_dim), nn.ReLU()])
            self.encoder = nn.Sequential(*enc_layers)

            dec_layers = []
            in_dim = latent_dim
            for h in reversed(hidden):
                dec_layers.extend([nn.Linear(in_dim, h), nn.ReLU()])
                in_dim = h
            dec_layers.append(nn.Linear(in_dim, input_dim))
            self.decoder = nn.Sequential(*dec_layers)

        def forward(self, x):
            encoded = self.encoder(x)
            decoded = self.decoder(encoded)
            return encoded, decoded


def fit_shallow_sparse_autoencoder(Z, trainIdx, testIdx, latentDim, opts):
    """Trains a 1-hidden layer shallow sparse autoencoder in PyTorch."""
    n_features = Z.shape[1]
    model = ShallowSparseAutoencoder(n_features, latentDim)
    optimizer = optim.Adam(model.parameters(), lr=opts['initialLearnRate'], weight_decay=1e-4)
    criterion = nn.MSELoss()

    x_train = torch.tensor(Z[trainIdx], dtype=torch.float32)
    dataset = TensorDataset(x_train)
    loader = DataLoader(dataset, batch_size=opts['miniBatchSize'], shuffle=True)

    model.train()
    for _ in range(opts['autoencoderMaxEpochs']):
        for batch, in loader:
            optimizer.zero_grad()
            encoded, decoded = model(batch)
            loss = criterion(decoded, batch) + 0.1 * torch.mean(torch.abs(encoded))  # Sparsity penalty
            loss.backward()
            optimizer.step()

    model.eval()
    with torch.no_grad():
        enc_tr, dec_tr = model(x_train)
        enc_te, dec_te = model(torch.tensor(Z[testIdx], dtype=torch.float32))

    return enc_tr.numpy(), enc_te.numpy(), dec_tr.numpy(), dec_te.numpy(), model


def fit_deep_fully_connected_autoencoder(Z, trainIdx, testIdx, latentDim, opts):
    """Trains a multi-layer symmetric encoder-decoder in PyTorch."""
    n_features = Z.shape[1]
    model = DeepFullyConnectedAutoencoder(n_features, latentDim, opts['deepHiddenUnits'])
    optimizer = optim.Adam(model.parameters(), lr=opts['initialLearnRate'])
    criterion = nn.MSELoss()

    x_train = torch.tensor(Z[trainIdx], dtype=torch.float32)
    dataset = TensorDataset(x_train)
    loader = DataLoader(dataset, batch_size=opts['miniBatchSize'], shuffle=True)

    model.train()
    for _ in range(opts['autoencoderMaxEpochs']):
        for batch, in loader:
            optimizer.zero_grad()
            _, decoded = model(batch)
            loss = criterion(decoded, batch)
            loss.backward()
            optimizer.step()

    model.eval()
    with torch.no_grad():
        enc_tr, dec_tr = model(x_train)
        enc_te, dec_te = model(torch.tensor(Z[testIdx], dtype=torch.float32))

    return enc_tr.numpy(), enc_te.numpy(), dec_tr.numpy(), dec_te.numpy(), model


def run_autoencoder_order_sweep(Z, yLog, yRaw, trainIdx, testIdx, opts):
    """Evaluates autoencoder surrogate performance across requested latent dimensions."""
    metricsTable = pd.DataFrame()
    autoencoders = {}

    if not opts['runDeepAutoencoder']:
        reason = "Skipped because runDeepAutoencoder=false."
    elif not TORCH_AVAILABLE:
        reason = "Skipped because PyTorch is not installed in the environment."
    elif "shallow_sparse" not in opts['autoencoderModels'] and "deep_fully_connected" not in opts['autoencoderModels']:
        reason = "Skipped because no autoencoder model was requested."
    else:
        reason = ""

    if reason != "":
        write_autoencoder_note(opts['outDir'], reason)
        return {'available': False, 'reason': reason, 'metricsTable': metricsTable, 'autoencoders': autoencoders}

    rows = []
    for latentDim in opts['latentDims']:
        latentDim = min(latentDim, Z.shape[1])

        if "shallow_sparse" in opts['autoencoderModels']:
            try:
                encTr, encTe, decTr, decTe, modelObj = fit_shallow_sparse_autoencoder(
                    Z, trainIdx, testIdx, latentDim, opts
                )
                rows = append_autoencoder_metrics(
                    rows, "shallow_sparse_autoencoder_quadratic", latentDim,
                    encTr, encTe, decTr, decTe, Z, yLog, yRaw, trainIdx, testIdx, opts
                )
                autoencoders[f"shallow_sparse_latent_{latentDim}"] = modelObj
            except Exception as err:
                warnings.warn(f"Shallow sparse autoencoder latent dim {latentDim} failed: {err}")

        if "deep_fully_connected" in opts['autoencoderModels']:
            try:
                encTr, encTe, decTr, decTe, modelObj = fit_deep_fully_connected_autoencoder(
                    Z, trainIdx, testIdx, latentDim, opts
                )
                rows = append_autoencoder_metrics(
                    rows, "deep_fully_connected_autoencoder_quadratic", latentDim,
                    encTr, encTe, decTr, decTe, Z, yLog, yRaw, trainIdx, testIdx, opts
                )
                autoencoders[f"deep_fc_latent_{latentDim}"] = modelObj
            except Exception as err:
                warnings.warn(f"Deep fully connected autoencoder latent dim {latentDim} failed: {err}")

    columns = [
        'model', 'latent_dim', 'variance_retained', 'rmse_log10', 'r2_log10',
        'median_relative_error', 'p95_relative_error',
        'train_reconstruction_rmse', 'test_reconstruction_rmse'
    ]
    metricsTable = pd.DataFrame(rows, columns=columns) if rows else pd.DataFrame(columns=columns)
    metricsTable.to_csv(os.path.join(opts['outDir'], "matlab_autoencoder_order_metrics.csv"), index=False)

    return {'available': len(rows) > 0, 'reason': "", 'metricsTable': metricsTable, 'autoencoders': autoencoders}


def append_autoencoder_metrics(rows, modelName, latentDim, encTr, encTe, decTr, decTe, Z, yLog, yRaw, trainIdx, testIdx, opts):
    phiTrain, _ = quadratic_features(encTr)
    phiTest, _ = quadratic_features(encTe)
    beta = ridge_regression(phiTrain, yLog[trainIdx], opts['regressionRidge'])
    
    predLog = phiTest @ beta
    pred = 10.0**predLog - 1e-6
    rmseLog, r2Log, medianRel, p95Rel = prediction_metrics(yLog[testIdx], yRaw[testIdx], predLog, pred)
    
    trainRecRmse = np.sqrt(np.mean((Z[trainIdx] - decTr)**2))
    testRecRmse = np.sqrt(np.mean((Z[testIdx] - decTe)**2))
    
    rows.append([
        modelName, latentDim, np.nan, rmseLog, r2Log,
        medianRel, p95Rel, trainRecRmse, testRecRmse
    ])
    return rows


# ==============================================================================
# Visualization Functions
# ==============================================================================

def plot_explained_variance(explainedTable, outDir):
    fig, ax1 = plt.subplots(figsize=(8.6, 5.2))
    ax2 = ax1.twinx()

    ax1.bar(explainedTable['pc'], 100 * explainedTable['variance_fraction'], color='C0', alpha=0.8)
    ax1.set_ylabel("Variance per PC, %", color='C0')
    ax1.set_xlabel("Principal component")

    ax2.plot(explainedTable['pc'], 100 * explainedTable['cumulative_variance'], "-o", color='C1', linewidth=1.8)
    ax2.set_ylabel("Cumulative variance, %", color='C1')

    plt.title("PCA/SVD explained variance")
    ax1.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(outDir, "matlab_svd_explained_variance.png"), dpi=220)
    plt.close()


def plot_order_metrics(svdTable, aeTable, outDir):
    plt.figure(figsize=(9.0, 5.6))
    plt.plot(svdTable['latent_dim'], svdTable['rmse_log10'], "-o", linewidth=1.8, label="PCA/SVD quadratic ROM")

    if not aeTable.empty:
        models = aeTable['model'].unique()
        markers = ["-s", "-d", "-^", "-v"]
        for i, mod in enumerate(models):
            sub = aeTable[aeTable['model'] == mod].sort_values('latent_dim')
            plt.plot(
                sub['latent_dim'], sub['rmse_log10'], markers[i % len(markers)],
                linewidth=1.8, label=mod.replace("_", " ")
            )

    plt.axvline(5, linestyle="--", color="gray", alpha=0.7, label="5 PCs")
    plt.axvline(7, linestyle="--", color="gray", alpha=0.7, label="7 PCs")
    plt.grid(True)
    plt.xlabel("Latent dimension")
    plt.ylabel(r"Test RMSE in $\log_{10}(U_{HT})$")
    plt.legend(loc="upper right")
    plt.title("Reduced-order prediction error")
    plt.tight_layout()
    plt.savefig(os.path.join(outDir, "matlab_svd_autoencoder_order_comparison.png"), dpi=220)
    plt.close()


def plot_pc_scores(scoresTrain, yLogTrain, outDir):
    if scoresTrain.shape[1] < 2:
        return
    plt.figure(figsize=(7.6, 6.2))
    sc = plt.scatter(scoresTrain[:, 0], scoresTrain[:, 1], c=yLogTrain, s=26, cmap='viridis')
    plt.colorbar(sc, label=r"$\log_{10}(U_{HT})$")
    plt.grid(True)
    plt.xlabel("PC1 score")
    plt.ylabel("PC2 score")
    plt.title("Training data projected onto first two PCs")
    plt.tight_layout()
    plt.savefig(os.path.join(outDir, "matlab_svd_pc1_pc2_scores.png"), dpi=220)
    plt.close()


def plot_direct_surrogate_map(xMean, xStd, featureNames, trainIdx, Z, yLog, svdResult, aeResult, opts):
    try:
        mapRun = run_ht_journal_analysis(
            sweepMode="cit_map",
            outDir=opts['outDir'],
            makePlots=False,
            runAutoencoder=False,
            runRomOrderStudy=False,
            runMonteCarlo=False,
            diameter_um=opts['diameter_um'],
            tcType=opts['tcType'],
            nSamples=1,
            sampleSeed=opts['sampleSeed']
        )
    except Exception as err:
        warnings.warn(f"Direct-vs-surrogate map was skipped because map solve failed: {err}")
        return

    mapData = mapRun['data']
    Xmap = mapData[featureNames].values
    Zmap = (Xmap - xMean) / xStd
    direct = mapData['WorstCaseCorrected_degF'].values

    scoresMap = Zmap @ svdResult['V'][:, :svdResult['bestPC']]
    phiMap, _ = quadratic_features(scoresMap)
    svdPred = 10.0**(phiMap @ svdResult['bestBeta']) - 1e-6

    aePred = np.full_like(direct, np.nan)
    aeLabel = "autoencoder unavailable"

    if aeResult.get('available', False) and not aeResult['metricsTable'].empty:
        aeRows = aeResult['metricsTable']
        bestIdx = aeRows['rmse_log10'].idxmin()
        bestRow = aeRows.loc[bestIdx]
        latentDim = int(bestRow['latent_dim'])
        modelName = str(bestRow['model'])

        try:
            modelKey = f"shallow_sparse_latent_{latentDim}" if "shallow" in modelName else f"deep_fc_latent_{latentDim}"
            modelObj = aeResult['autoencoders'][modelKey]
            modelObj.eval()
            
            with torch.no_grad():
                latentTrain, _ = modelObj(torch.tensor(Z[trainIdx], dtype=torch.float32))
                latentMap, _ = modelObj(torch.tensor(Zmap, dtype=torch.float32))
                
            phiTrain, _ = quadratic_features(latentTrain.numpy())
            phiAEMap, _ = quadratic_features(latentMap.numpy())
            betaAE = ridge_regression(phiTrain, yLog[trainIdx], opts['regressionRidge'])
            aePred = 10.0**(phiAEMap @ betaAE) - 1e-6
            aeLabel = f"{modelName.replace('_', ' ')}, {latentDim} latent vars"
        except Exception as err:
            warnings.warn(f"Autoencoder map prediction failed: {err}")

    temps = np.unique(mapData['Tj_degF'])
    lds = np.unique(mapData['L_over_d'])
    LDgrid, Tgrid = np.meshgrid(lds, temps)

    directM = direct.reshape(len(temps), len(lds))
    svdM = svdPred.reshape(len(temps), len(lds))
    aeM = aePred.reshape(len(temps), len(lds)) if np.all(np.isfinite(aePred)) else None
    errM = np.log10(np.maximum(np.abs((aeM if aeM is not None else svdM) - directM), 1e-6))

    fig, axes = plt.subplots(2, 2, figsize=(11.2, 8.4))

    # Panel 1: Direct Solver
    cf1 = axes[0, 0].contourf(LDgrid, Tgrid, np.log10(np.maximum(directM, 1e-6)), 24)
    fig.colorbar(cf1, ax=axes[0, 0])
    axes[0, 0].set_title(r"Direct solver: $\log_{10}(U_{HT})$")

    # Panel 2: SVD ROM
    cf2 = axes[0, 1].contourf(LDgrid, Tgrid, np.log10(np.maximum(svdM, 1e-6)), 24)
    fig.colorbar(cf2, ax=axes[0, 1])
    axes[0, 1].set_title(f"PCA/SVD ROM: {svdResult['bestPC']} PCs")

    # Panel 3: Autoencoder ROM
    if aeM is not None:
        cf3 = axes[1, 0].contourf(LDgrid, Tgrid, np.log10(np.maximum(aeM, 1e-6)), 24)
        fig.colorbar(cf3, ax=axes[1, 0])
        axes[1, 0].set_title(aeLabel)
    else:
        axes[1, 0].text(0.1, 0.5, "Autoencoder map unavailable")
        axes[1, 0].set_title("Autoencoder ROM")

    # Panel 4: Error map
    cf4 = axes[1, 1].contourf(LDgrid, Tgrid, errM, 24)
    fig.colorbar(cf4, ax=axes[1, 1])
    axes[1, 1].set_title(r"Absolute error: $\log_{10}(|\Delta U_{HT}|)$")

    for ax in axes.flat:
        ax.grid(True)
        ax.set_xlabel("L/d")
        ax.set_ylabel("CIT junction temperature, degF")

    plt.tight_layout()
    plt.savefig(os.path.join(opts['outDir'], "matlab_direct_svd_autoencoder_map.png"), dpi=220)
    plt.close()


def make_settings_table(opts, featureNames, nRows, nTrain, nTest):
    rows = [
        ["purpose", "Compare PCA/SVD ROM with shallow sparse and deep autoencoders"],
        ["solver", "Python heat-transfer thermocouple solver"],
        ["thermocouple_type", str(opts['tcType'])],
        ["diameter_um", str(opts['diameter_um'])],
        ["sweep_mode", opts['sweepMode']],
        ["n_samples_requested", str(opts['nSamples'])],
        ["sample_seed", str(opts['sampleSeed'])],
        ["feature_set", opts['featureSet']],
        ["features", ", ".join(featureNames)],
        ["target", opts['targetName']],
        ["target_transform", "log10(target + 1e-6)"],
        ["latent_dimensions", ", ".join(map(str, opts['latentDims']))],
        ["svd_model", "SVD scores of standardized features + quadratic ridge regression"],
        ["autoencoder_models", ", ".join(opts['autoencoderModels'])],
        ["deep_hidden_units", ", ".join(map(str, opts['deepHiddenUnits']))],
        ["autoencoder_epochs", str(opts['autoencoderMaxEpochs'])],
        ["autoencoder_initial_learning_rate", str(opts['initialLearnRate'])],
        ["autoencoder_mini_batch_size", str(opts['miniBatchSize'])],
        ["rows_total", str(nRows)],
        ["rows_train", str(nTrain)],
        ["rows_test", str(nTest)],
        ["random_seed", str(opts['randomSeed'])]
    ]
    return pd.DataFrame(rows, columns=['item', 'value'])


# ==============================================================================
# Main Execution Driver
# ==============================================================================

def run_ht_svd_autoencoder_case(**kwargs):
    """Main function executing the SVD/PCA and Autoencoder case study."""
    opts = {
        'sweepMode': "factorial",
        'outDir': "../outputs/matlab_svd_autoencoder_case",
        'tcType': 'K',
        'diameter_um': 90,
        'nSamples': 8000,
        'sampleSeed': 41,
        'featureSet': "expanded",
        'latentDims': [3, 5, 7, 9],
        'testFraction': 0.25,
        'randomSeed': 23,
        'targetName': "WorstCaseCorrected_degF",
        'runDeepAutoencoder': True,
        'autoencoderModels': ["shallow_sparse", "deep_fully_connected"],
        'autoencoderMaxEpochs': 500,
        'deepHiddenUnits': [64, 32],
        'initialLearnRate': 1e-3,
        'miniBatchSize': 256,
        'regressionRidge': 1e-6,
        'makePlots': True
    }
    opts.update(kwargs)

    if not os.path.exists(opts['outDir']):
        os.makedirs(opts['outDir'])

    solver = run_ht_journal_analysis(
        sweepMode=opts['sweepMode'],
        outDir=opts['outDir'],
        makePlots=False,
        runAutoencoder=False,
        runRomOrderStudy=False,
        runMonteCarlo=False,
        diameter_um=opts['diameter_um'],
        tcType=opts['tcType'],
        nSamples=opts['nSamples'],
        sampleSeed=opts['sampleSeed']
    )

    data = solver['data']
    Xraw, yRaw, featureNames = build_case_feature_matrix(data, opts['featureSet'], opts['targetName'])
    Z, xMean, xStd = standardize_columns(Xraw)
    yLog = np.log10(yRaw + 1e-6)

    np.random.seed(opts['randomSeed'])
    idx = np.random.permutation(len(Z))
    nTest = max(1, int(round(opts['testFraction'] * len(idx))))
    testIdx = idx[:nTest]
    trainIdx = idx[nTest:]

    svdResult = run_svd_order_sweep(Z, yLog, yRaw, trainIdx, testIdx, featureNames, opts)
    aeResult = run_autoencoder_order_sweep(Z, yLog, yRaw, trainIdx, testIdx, opts)

    settings = make_settings_table(opts, featureNames, len(data), len(trainIdx), len(testIdx))
    settings.to_csv(os.path.join(opts['outDir'], "matlab_svd_autoencoder_case_settings.csv"), index=False)

    if opts['makePlots']:
        plot_explained_variance(svdResult['explainedTable'], opts['outDir'])
        plot_order_metrics(svdResult['orderTable'], aeResult['metricsTable'], opts['outDir'])
        plot_pc_scores(svdResult['scoresTrain'], yLog[trainIdx], opts['outDir'])
        plot_direct_surrogate_map(xMean, xStd, featureNames, trainIdx, Z, yLog, svdResult, aeResult, opts)

    print("\nSVD/PCA and Autoencoder case study complete.")
    print(f"Outputs saved to: {opts['outDir']}\n")
    print(svdResult['orderTable'])

    if not aeResult['metricsTable'].empty:
        print("\nAutoencoder Metrics:")
        print(aeResult['metricsTable'])
    else:
        print("\nAutoencoder metrics were not generated. See settings CSV or log messages for details.")

    return {
        'settings': settings,
        'data': data,
        'featureNames': featureNames,
        'svd': svdResult,
        'autoencoder': aeResult
    }