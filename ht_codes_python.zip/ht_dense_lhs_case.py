# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 21:20:24 2026

@author: laksh
"""

from ht_svd_autoencoder_case import run_ht_svd_autoencoder_case


def run_ht_dense_lhs_case():
    """Dense Latin Hypercube Sampling (LHS) case study for SVD/PCA and autoencoder comparison."""
    denseReport = run_ht_svd_autoencoder_case(
        sweepMode="lhs",
        nSamples=8000,
        sampleSeed=41,
        tcType="K",
        diameter_um=90,
        featureSet="expanded",
        latentDims=[3, 5, 7, 9],
        runDeepAutoencoder=True,
        autoencoderModels=["shallow_sparse", "deep_fully_connected"],
        autoencoderMaxEpochs=1000,
        deepHiddenUnits=[64, 32],
        initialLearnRate=1e-3,
        miniBatchSize=256,
        outDir="../outputs/matlab_svd_autoencoder_lhs",
    )
    return denseReport


if __name__ == "__main__":
    run_ht_dense_lhs_case()