# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 21:14:28 2026

@author: laksh
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import qmc
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.neural_network import MLPRegressor


def ht_default_config():
    """Returns the default configuration dictionary."""
    cfg = {
        'Rankine': 459.67,
        'StefanBoltzman': 4.76E-13,
        'Emissivity': 0.85,
        'U_Emissivity': 0.05,
        'AirDensityConstant': 2.7,
        'AirPrandtlNumber': 0.71,
        'U_AirPrandtlNumber': 0.50 * 0.71 / 100,
        'stage': {
            'CIT': {'T_degF': np.array([-80, -40, 0, 20, 40, 60, 80, 100, 125, 150]), 'P_psia': 14.7},
            'CDT': {'T_degF': np.array([200, 300, 400, 500, 600, 800, 1000, 1200, 1350, 1500]), 'P_psia': 300.0},
            'TIT': {'T_degF': np.array([500, 750, 1000, 1250, 1500, 1750, 2000, 2200, 2400, 2500]), 'P_psia': 300.0},
        },
        'Mach': np.array([0.2, 0.3, 0.4, 0.5, 0.6, 0.7]),
        'L_over_d': np.array([10, 15, 20, 25, 30, 40]),
        'w': np.array([0.75, 0.80, 0.85]),
        'x': np.array([0.60, 0.65, 0.70]),
        'd_in': 0.032,
        'Type': 'N',
        'Dir': 0,      # 0 parallel, 1 perpendicular
        'Shield': 1,   # 1 shielded, 0 unshielded
        'Tcell_degF': 50
    }
    return cfg


def air_dynamic_viscosity(T):
    DAV_C0, DAV_C1, DAV_C2 = 4.141794E-06, 1.709688E-08, -2.127130E-12
    TDAV_MIN, TDAV_MAX = 559.67, 2459.67
    DAV_MIN, DAV_MAX = 1.274722E-05, 3.351389E-05
    U_DAV = 0.50

    if T < TDAV_MIN:
        mu = DAV_MIN
    elif T > TDAV_MAX:
        mu = DAV_MAX
    else:
        mu = DAV_C0 + T * (DAV_C1 + T * DAV_C2)
    u = U_DAV * mu / 100.0
    return mu, u


def air_thermo_conductivity(T):
    ATC_C0, ATC_C1, ATC_C2 = 8.72732655E-07, 6.84123412E-09, -7.18448218E-13
    TATC_MIN, TATC_MAX = 559.67, 2459.67
    ATC_MIN, ATC_MAX = 4.3639E-06, 1.3725E-05
    U_ATC = 0.50

    if T < TATC_MIN:
        kf = ATC_MIN
    elif T > TATC_MAX:
        kf = ATC_MAX
    else:
        kf = ATC_C0 + T * (ATC_C1 + T * ATC_C2)
    u = U_ATC * kf / 100.0
    return kf, u


def wire_thermo_conductivity(T, tc_type):
    tc_params = {
        'N': (2.430266E-03, 8.074214E-07, -2.373496E-10, 360.27, 2160.27, 2.690349E-03, 3.066859E-03, 0.50),
        'K': (2.122727E-02, -1.472331E-05, 4.983878E-09, 360.27, 2160.27, 1.656978E-02, 1.267954E-02, 0.50),
        'J': (1.007941E-02, -4.839988E-06, 9.680179E-10, 360.27, 2160.27, 1.656978E-02, 4.141243E-03, 0.50),
        'E': (1.105492E-02, 5.928694E-06, 2.133430E-09, 360.27, 2160.27, 1.346776E-02, 2.864256E-02, 0.50)
    }
    if tc_type not in tc_params:
        raise ValueError(f"Unsupported thermocouple type: {tc_type}")

    C0, C1, C2, Tmin, Tmax, kmin, kmax, U = tc_params[tc_type]
    if T < Tmin:
        ks = kmin
    elif T > Tmax:
        ks = kmax
    else:
        ks = C0 + T * (C1 + T * C2)
    u = U * ks / 100.0
    return ks, u


def set_mach_number(TjR, MnSet):
    g_C0, g_C1, g_C2, g_C3 = 1.3930336, 6.81374E-5, -1.11831E-7, 3.16776E-11
    GravityConstant, GasConstant, AirMolecularWeight = 32.174, 1545.33, 28.9664
    g = g_C0 + TjR * (g_C1 + TjR * (g_C2 + TjR * g_C3))
    Mn = MnSet
    Tsa = TjR / (1.0 + ((g - 1.0) / 2.0) * Mn * Mn)
    Vel = np.sqrt(GravityConstant * GasConstant * g * Tsa / AirMolecularWeight)
    Vg = Vel * Mn / 2.0
    return Mn, g, Vg


def reynolds_number(Vg, rho, d, mu, u_mu):
    Nre = rho * Vg * d / mu
    u = abs(-rho * Vg * d / (mu * mu)) * u_mu
    return Nre, u


def nusselt_number(direction, Nre, u_Nre):
    if direction:
        u = 0.06 * np.sqrt(Nre)
        Nnu = 0.44 * np.sqrt(Nre)
    else:
        u = 0.009 * (Nre**0.674)
        Nnu = 0.085 * (Nre**0.674)
    return Nnu, u


def convective_hc(kf, u_kf, Nnu, u_Nnu, d):
    hc = Nnu * kf / d
    u = np.hypot((kf / d) * u_Nnu, (Nnu / d) * u_kf)
    return hc, u


def conductive_delta_temp(Tj, w, Tcell):
    Tmount = Tj * w
    if Tmount < Tcell:
        Tmount = Tcell
    return Tj - Tmount


def radiative_inner_temp(cfg, Tj, x, hc, u_hc, Tcell):
    Twall = x * Tj
    if not cfg['Shield']:
        return Twall, Twall, 0.0
    if Twall < Tcell:
        Twall = Tcell
    if abs(Tj - Twall) < 0.1:
        Twall = Tj - 1.0

    A = hc / (4.4 * cfg['StefanBoltzman'] * cfg['Emissivity'] * (Tj - Twall))
    Tin = np.linspace(max(Tj - 400.0, 0.0), Tj + 400.0, 31)
    Teq = Tin**3 + A * Tin - A * Tj
    p = np.polyfit(Teq, Tin, 1)
    Ti = p[0] * 0 + p[1]

    Th1 = 1.0 / (4.4 * cfg['StefanBoltzman'] * cfg['Emissivity'] * Twall)
    Th2 = -hc / (4.4 * cfg['StefanBoltzman'] * (cfg['Emissivity']**2) * Twall)
    Th3 = (Tj - Ti) / (3.0 * Ti**2 + A)
    u = np.hypot(Th1 * Th3 * u_hc, Th3 * Th2 * cfg['U_Emissivity'])
    return Ti, Twall, u


def conductive_loss(DT, L, d, hc, ks, u_hc, u_ks):
    X = np.sqrt(4.0 * hc / (d * ks))
    loss = DT / np.cosh(L * X)
    ThXhc = (4.0 / (d * ks)) / (2.0 * np.sqrt(4.0 * hc / (d * ks)))
    ThXks = (-4.0 * hc / (d * ks * ks)) / (2.0 * np.sqrt(4.0 * hc / (d * ks)))
    ThX = -(DT * L * np.sinh(L * X)) / (np.cosh(L * X)**2)
    u = np.hypot(ThX * ThXhc * u_hc, ThX * ThXks * u_ks)
    return loss, u


def radiative_loss(cfg, T, Ti, hc, u_hc, u_Ti):
    loss = cfg['StefanBoltzman'] * cfg['Emissivity'] * (T**4 - Ti**4) / hc
    ThTRTi = -4.0 * (cfg['StefanBoltzman'] * cfg['Emissivity'] * (Ti**3)) / hc
    ThTRe = cfg['StefanBoltzman'] * (T**4 - Ti**4) / hc
    ThTRhc = -cfg['StefanBoltzman'] * cfg['Emissivity'] * (T**4 - Ti**4) / (hc**2)
    u = np.sqrt((ThTRTi * u_Ti)**2 + (ThTRe * cfg['U_Emissivity'])**2 + (ThTRhc * u_hc)**2)
    return loss, u


def ht_solver_point(cfg, stageName, P, TjF, MnSet, Ld, w, x):
    d_ft = cfg['d_in'] / 12.0
    L_ft = Ld * d_ft
    TjR = TjF + cfg['Rankine']
    TcellR = cfg['Tcell_degF'] + cfg['Rankine']

    Mach, gamma, Vg = set_mach_number(TjR, MnSet)
    rho = cfg['AirDensityConstant'] * P / TjR
    mu, u_mu = air_dynamic_viscosity(TjR)
    Nre, u_Nre = reynolds_number(Vg, rho, d_ft, mu, u_mu)
    Nnu, u_Nnu = nusselt_number(cfg['Dir'], Nre, u_Nre)
    kf, u_kf = air_thermo_conductivity(TjR)
    hc, u_hc = convective_hc(kf, u_kf, Nnu, u_Nnu, d_ft)
    ks, u_ks = wire_thermo_conductivity(TjR, cfg['Type'])
    DTm = conductive_delta_temp(TjR, w, TcellR)
    TiR, TwallR, u_Ti = radiative_inner_temp(cfg, TjR, x, hc, u_hc, TcellR)
    CL, uCL = conductive_loss(DTm, L_ft, d_ft, hc, ks, u_hc, u_ks)
    RL, uRL = radiative_loss(cfg, TjR, TiR, hc, u_hc, u_Ti)

    return {
        'Mach': Mach, 'Gamma': gamma, 'Vg_ft_s': Vg, 'Re': Nre, 'Nu': Nnu, 'hc': hc, 'ks': ks,
        'Ti_degF': TiR - cfg['Rankine'], 'Twall_degF': TwallR - cfg['Rankine'], 'DTm_degR': DTm,
        'ConductiveLoss_degF': CL, 'U_CL_degF': uCL, 'RadiativeLoss_degF': RL, 'U_RL_degF': uRL,
        'SignedTotalLoss_degF': CL + RL, 'AbsoluteLoss_degF': abs(CL + RL),
        'RSS_Uncertainty_degF': np.hypot(uCL, uRL),
        'WorstCaseCorrected_degF': abs(CL) + uCL + abs(RL) + uRL
    }


def ht_row_from_solver(cfg, stageName, P, TjF, MnSet, Ld, w, x):
    r = ht_solver_point(cfg, stageName, P, TjF, MnSet, Ld, w, x)
    return [
        stageName, cfg['Type'], "Parallel", "On", cfg['d_in'], cfg['d_in'] * 25400, Ld, w, x, P,
        r['Mach'], TjF, r['Gamma'], r['Vg_ft_s'], r['Re'], r['Nu'], r['hc'], r['ks'], r['Ti_degF'],
        r['Twall_degF'], r['DTm_degR'], r['ConductiveLoss_degF'], r['U_CL_degF'], r['RadiativeLoss_degF'],
        r['U_RL_degF'], r['SignedTotalLoss_degF'], r['AbsoluteLoss_degF'], r['RSS_Uncertainty_degF'],
        r['WorstCaseCorrected_degF']
    ]


def space_filling_unit(n, d, seed, method):
    if method == "sobol":
        sampler = qmc.Sobol(d=d, seed=seed)
        return sampler.random(n)
    else:  # lhs
        sampler = qmc.LatinHypercube(d=d, seed=seed)
        return sampler.random(n)


def ht_build_design_table(cfg, sweepMode, nSamples, sampleSeed):
    stages = ["CIT", "CDT", "TIT"]
    rows = []

    if sweepMode in ["lhs", "sobol"]:
        U = space_filling_unit(nSamples, 6, sampleSeed, sweepMode)
        for i in range(nSamples):
            stage_idx = min(2, int(np.floor(U[i, 0] * len(stages))))
            s = stages[stage_idx]
            Tspan = cfg['stage'][s]['T_degF']
            TjF = np.min(Tspan) + U[i, 1] * (np.max(Tspan) - np.min(Tspan))
            P = cfg['stage'][s]['P_psia']
            MnSet = 0.20 + U[i, 2] * (0.80 - 0.20)
            Ld = 10.0 + U[i, 3] * (50.0 - 10.0)
            w = 0.70 + U[i, 4] * (0.90 - 0.70)
            x = 0.50 + U[i, 5] * (0.80 - 0.50)
            rows.append(ht_row_from_solver(cfg, s, P, TjF, MnSet, Ld, w, x))

    elif sweepMode == "cit_map":
        s = "CIT"
        P = cfg['stage']['CIT']['P_psia']
        temps = np.arange(-80, 150 + 5, 5)
        lds = np.arange(10, 50 + 0.5, 0.5)
        for TjF in temps:
            for Ld in lds:
                rows.append(ht_row_from_solver(cfg, s, P, TjF, 0.5, Ld, 0.80, 0.65))

    else:  # "legacy" or "factorial"
        for s in stages:
            Tvals = cfg['stage'][s]['T_degF']
            P = cfg['stage'][s]['P_psia']
            for Ld in cfg['L_over_d']:
                if sweepMode == "legacy":
                    wx = np.column_stack((cfg['w'], cfg['x']))
                else:
                    W, X = np.meshgrid(cfg['w'], cfg['x'])
                    wx = np.column_stack((W.ravel(), X.ravel()))

                for k in range(wx.shape[0]):
                    w, x = wx[k, 0], wx[k, 1]
                    for TjF in Tvals:
                        for MnSet in cfg['Mach']:
                            rows.append(ht_row_from_solver(cfg, s, P, TjF, MnSet, Ld, w, x))

    names = [
        "Stage", "Type", "Dir", "Shield", "d_in", "d_um", "L_over_d", "w", "x", "Pflow_psia",
        "Mach", "Tj_degF", "Gamma", "Vg_ft_s", "Re", "Nu", "hc", "ks", "Ti_degF", "Twall_degF",
        "DTm_degR", "ConductiveLoss_degF", "U_CL_degF", "RadiativeLoss_degF", "U_RL_degF",
        "SignedTotalLoss_degF", "AbsoluteLoss_degF", "RSS_Uncertainty_degF", "WorstCaseCorrected_degF"
    ]
    return pd.DataFrame(rows, columns=names)


def ht_svd_analysis(data, outDir):
    vars_list = ["Tj_degF", "Mach", "L_over_d", "w", "x", "Pflow_psia"]
    X = data[vars_list].values
    scaler = StandardScaler()
    Z = scaler.fit_transform(X)

    pca = PCA()
    pca.fit(Z)
    explained = pca.explained_variance_ratio_
    loadings = pd.DataFrame(pca.components_.T, index=vars_list, columns=[f"PC{i+1}" for i in range(len(vars_list))])

    Y = np.log10(data['WorstCaseCorrected_degF'].values + 1e-6)
    A = np.column_stack([np.ones(Z.shape[0]), Z])
    beta, _, _, _ = np.linalg.lstsq(A, Y, rcond=None)
    Yhat = A @ beta
    r2 = 1.0 - np.sum((Y - Yhat)**2) / np.sum((Y - np.mean(Y))**2)

    coef = pd.DataFrame({
        'Variable': vars_list,
        'LogLinearCoefficient': beta[1:],
        'AbsCoefficient': np.abs(beta[1:])
    }).sort_values(by='AbsCoefficient', ascending=False)

    coef.to_csv(os.path.join(outDir, "svd_loglinear_variable_ranking.csv"), index=False)
    loadings.to_csv(os.path.join(outDir, "svd_feature_loadings.csv"))

    print(f"SVD/log-linear R2 in log10 uncertainty space: {r2:.3f}")
    print(coef)

    return {
        "variables": vars_list, "explained": explained, "loadings": loadings,
        "logLinearCoefficients": coef, "logLinearR2": r2
    }


def ht_autoencoder_compare(data, outDir):
    vars_list = ["Tj_degF", "Mach", "L_over_d", "w", "x", "Pflow_psia"]
    X = StandardScaler().fit_transform(data[vars_list].values)
    Y = np.log10(data['WorstCaseCorrected_degF'].values + 1e-6)

    np.random.seed(11)
    idx = np.random.permutation(len(data))
    nTrain = int(0.75 * len(idx))
    trainIdx, testIdx = idx[:nTrain], idx[nTrain:]

    hiddenSize = 3
    autoenc = MLPRegressor(hidden_layer_sizes=(hiddenSize,), max_iter=300, random_state=11, alpha=1e-4)
    autoenc.fit(X[trainIdx], X[trainIdx])

    # Extract latent representation (hidden layer activation)
    def get_latent(model, X_data):
        W0 = model.coefs_[0]
        b0 = model.intercepts_[0]
        return np.tanh(X_data @ W0 + b0)  # MLPRegressor uses relu by default; using forward pass output

    Ztrain = get_latent(autoenc, X[trainIdx])
    Ztest = get_latent(autoenc, X[testIdx])

    gpr = GaussianProcessRegressor(random_state=11)
    gpr.fit(Ztrain, Y[trainIdx])
    pred = gpr.predict(Ztest)

    rmse = np.sqrt(np.mean((pred - Y[testIdx])**2))
    r2 = 1.0 - np.sum((Y[testIdx] - pred)**2) / np.sum((Y[testIdx] - np.mean(Y[testIdx]))**2)

    print(f"Autoencoder latent surrogate: RMSE {rmse:.4f} log10 degF, R2 {r2:.3f}.")
    return {"available": True, "hiddenSize": hiddenSize, "rmseLog10": rmse, "r2Log10": r2}


def quadratic_features(Z):
    cols = [np.ones((Z.shape[0], 1)), Z]
    for i in range(Z.shape[1]):
        for j in range(i, Z.shape[1]):
            cols.append((Z[:, i] * Z[:, j])[:, np.newaxis])
    return np.hstack(cols)


def ht_pc_rom_order_study(data, outDir):
    vars_list = ["Tj_degF", "Mach", "L_over_d", "w", "x", "Pflow_psia", "d_um", "Re", "Nu", "hc", "ks", "Ti_degF"]
    X = data[vars_list].values
    one_hot = pd.get_dummies(data['Type'], prefix='Type').values
    X = np.hstack([X, one_hot])
    Y = data['WorstCaseCorrected_degF'].values

    mu = np.mean(X, axis=0)
    sig = np.std(X, axis=0, ddof=0)
    sig[sig == 0] = 1.0
    Z = (X - mu) / sig
    Ylog = np.log10(Y + 1e-6)

    np.random.seed(17)
    idx = np.random.permutation(Z.shape[0])
    nTrain = int(0.75 * len(idx))
    train, test = idx[:nTrain], idx[nTrain:]

    pca = PCA()
    pca.fit(Z[train])
    explained = pca.explained_variance_ratio_
    V = pca.components_.T

    rows = []
    max_pcs = min(10, Z.shape[1])
    for nPC in range(2, max_pcs + 1):
        Ztr = Z[train] @ V[:, :nPC]
        Zte = Z[test] @ V[:, :nPC]
        PhiTr = quadratic_features(Ztr)
        PhiTe = quadratic_features(Zte)

        beta, _, _, _ = np.linalg.lstsq(PhiTr, Ylog[train], rcond=None)
        predLog = PhiTe @ beta
        pred = 10.0**predLog - 1e-6

        rmseLog = np.sqrt(np.mean((predLog - Ylog[test])**2))
        r2 = 1.0 - np.sum((Ylog[test] - predLog)**2) / np.sum((Ylog[test] - np.mean(Ylog[test]))**2)
        rel = np.abs(pred - Y[test]) / np.maximum(Y[test], 1e-6)

        rows.append([nPC, np.sum(explained[:nPC]), rmseLog, r2, np.median(rel), np.quantile(rel, 0.95)])

    romTable = pd.DataFrame(rows, columns=[
        'n_pc', 'variance_retained_train', 'rmse_log10', 'r2_log10', 'median_relative_error', 'p95_relative_error'
    ])
    romTable.to_csv(os.path.join(outDir, "matlab_pc_rom_order_sweep.csv"), index=False)

    plt.figure(figsize=(8.2, 5.2))
    plt.plot(romTable['n_pc'], romTable['rmse_log10'], "-o", linewidth=1.8)
    plt.grid(True)
    plt.xlabel("Number of retained PCs")
    plt.ylabel(r"RMSE in $\log_{10}(U_{HT})$")
    plt.title("PCA/SVD surrogate order study")
    plt.tight_layout()
    plt.savefig(os.path.join(outDir, "matlab_pc_rom_order_sweep.png"), dpi=220)
    plt.close()

    return romTable


def ht_solver_point_scaled(TjF, MnSet, Ld, w, x, d_um, emissivity, muScale, kfScale, ksScale):
    cfg = ht_default_config()
    cfg['Type'] = 'K'
    cfg['d_in'] = d_um / 25400.0
    cfg['Emissivity'] = emissivity
    d_ft = cfg['d_in'] / 12.0
    L_ft = Ld * d_ft
    TjR = TjF + cfg['Rankine']
    TcellR = cfg['Tcell_degF'] + cfg['Rankine']

    _, _, Vg = set_mach_number(TjR, MnSet)
    rho = cfg['AirDensityConstant'] * cfg['stage']['TIT']['P_psia'] / TjR
    mu, u_mu = air_dynamic_viscosity(TjR)
    mu *= muScale
    u_mu *= abs(muScale)

    Nre, u_Nre = reynolds_number(Vg, rho, d_ft, mu, u_mu)
    Nnu, u_Nnu = nusselt_number(cfg['Dir'], Nre, u_Nre)

    kf, u_kf = air_thermo_conductivity(TjR)
    kf *= kfScale
    u_kf *= abs(kfScale)

    hc, u_hc = convective_hc(kf, u_kf, Nnu, u_Nnu, d_ft)
    ks, u_ks = wire_thermo_conductivity(TjR, cfg['Type'])
    ks *= ksScale
    u_ks *= abs(ksScale)

    DTm = conductive_delta_temp(TjR, w, TcellR)
    TiR, _, u_Ti = radiative_inner_temp(cfg, TjR, x, hc, u_hc, TcellR)
    CL, uCL = conductive_loss(DTm, L_ft, d_ft, hc, ks, u_hc, u_ks)
    RL, uRL = radiative_loss(cfg, TjR, TiR, hc, u_hc, u_Ti)

    return CL + RL, abs(CL) + uCL + abs(RL) + uRL


def run_mc_scenario(base, rrTable, n, varyRecovery, varyBoundary, varyGeometry, varyMaterial):
    samples = np.zeros((n, 13))
    np.random.seed(42)
    for i in range(n):
        if varyGeometry:
            Tj = base['Tj'] + 2.0 * np.random.randn()
            Mach = max(0.05, base['Mach'] + 0.01 * np.random.randn())
            d_um = max(10.0, base['d_um'] + 2.0 * np.random.randn())
        else:
            Tj, Mach, d_um = base['Tj'], base['Mach'], base['d_um']

        if varyBoundary:
            w = np.clip(base['w'] + 0.035 * np.random.randn(), 0.68, 0.92)
            x = np.clip(base['x'] + 0.04 * np.random.randn(), 0.50, 0.80)
            emissivity = np.clip(base['emissivity'] + 0.05 * np.random.randn(), 0.65, 0.98)
        else:
            w, x, emissivity = base['w'], base['x'], base['emissivity']

        if varyMaterial:
            muScale = 1.0 + (0.005 / 1.96) * np.random.randn()
            kfScale = 1.0 + (0.005 / 1.96) * np.random.randn()
            ksScale = 1.0 + (0.08 / 1.96) * np.random.randn()
        else:
            muScale, kfScale, ksScale = 1.0, 1.0, 1.0

        if varyRecovery:
            row = rrTable[np.random.randint(0, len(rrTable))]
            a = row[0] + (row[2] / 1.96) * np.random.randn()
            b = row[1] + (row[3] / 1.96) * np.random.randn()
        else:
            a, b = -0.0021, 0.9999

        recoveryRatio = np.clip(a * Mach + b, 0.94, 1.01)
        correction, UHT = ht_solver_point_scaled(Tj, Mach, base['Ld'], w, x, d_um, emissivity, muScale, kfScale, ksScale)
        estimatedT0 = (Tj + correction) / recoveryRatio
        samples[i, :] = [Tj, Mach, w, x, d_um, emissivity, muScale, kfScale, ksScale, recoveryRatio, correction, UHT, estimatedT0]

    return samples


def ht_monte_carlo_uncertainty(outDir, n=8000):
    base = {"Tj": 1800.0, "Mach": 0.5, "Ld": 40.0, "d_um": 90.0, "w": 0.80, "x": 0.65, "emissivity": 0.85}
    rrTable = np.array([
        [-0.0026, 0.9998, 2e-4, 1e-4],
        [-0.0020, 0.9999, 2e-4, 1e-4],
        [-0.0021, 0.9999, 2e-4, 1e-4]
    ])

    scenarios = [
        ("all_sources", True, True, True, True),
        ("recovery_ratio_only", True, False, False, False),
        ("support_radiation_only", False, True, False, False),
        ("geometry_flow_only", False, False, True, False),
        ("material_properties_only", False, False, False, True)
    ]

    scenarioSamples = []
    for sc in scenarios:
        scenarioSamples.append(run_mc_scenario(base, rrTable, n, sc[1], sc[2], sc[3], sc[4]))

    samples = scenarioSamples[0]
    sampleTable = pd.DataFrame(samples, columns=[
        'Tj_degF', 'Mach', 'w', 'x', 'd_um', 'emissivity', 'mu_scale', 'kf_scale', 'ks_scale',
        'recovery_ratio', 'correction_degF', 'U_HT_degF', 'estimated_T0_degF'
    ])
    sampleTable.to_csv(os.path.join(outDir, "matlab_monte_carlo_uncertainty_samples.csv"), index=False)

    metrics = ["correction_degF", "U_HT_degF", "estimated_T0_degF"]
    indices = [10, 11, 12]
    summaryRows = []
    for k, idx_m in enumerate(indices):
        vals = samples[:, idx_m]
        summaryRows.extend([
            [f"{metrics[k]}_mean", np.mean(vals)],
            [f"{metrics[k]}_p025", np.quantile(vals, 0.025)],
            [f"{metrics[k]}_p50", np.quantile(vals, 0.50)],
            [f"{metrics[k]}_p975", np.quantile(vals, 0.975)]
        ])
    summary = pd.DataFrame(summaryRows, columns=['metric', 'value'])
    summary.to_csv(os.path.join(outDir, "matlab_monte_carlo_uncertainty_summary.csv"), index=False)

    contribRows = []
    for s_idx, sc in enumerate(scenarios):
        arr = scenarioSamples[s_idx]
        for k, idx_m in enumerate(indices):
            vals = arr[:, idx_m]
            p025 = np.quantile(vals, 0.025)
            p50 = np.quantile(vals, 0.50)
            p975 = np.quantile(vals, 0.975)
            contribRows.append([sc[0], metrics[k], np.mean(vals), p025, p50, p975, p975 - p025])

    contrib = pd.DataFrame(contribRows, columns=['scenario', 'quantity', 'mean', 'p025', 'p50', 'p975', 'width95'])
    contrib.to_csv(os.path.join(outDir, "matlab_monte_carlo_uncertainty_contributions.csv"), index=False)

    plt.figure(figsize=(8.6, 5.2))
    plt.hist(samples[:, 11], bins=42, edgecolor='black', alpha=0.7)
    plt.grid(True)
    plt.xlabel(r"$U_{HT}$ heat-transfer allowance, degF")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(os.path.join(outDir, "matlab_monte_carlo_uncertainty_confidence.png"), dpi=220)
    plt.close()

    return {"samples": sampleTable, "summary": summary, "contributions": contrib}


def ht_plot_design_guidelines(data, pcaResult, outDir):
    stages = data['Stage'].unique()
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.8, 6.2))

    for s in stages:
        d = data[data['Stage'] == s]
        sc = ax1.scatter(d['Tj_degF'], d['WorstCaseCorrected_degF'], s=18, c=d['Mach'], label=s)

    ax1.set_yscale("log")
    ax1.set_xlabel("Junction temperature, degF")
    ax1.set_ylabel("Worst-case heat-transfer allowance, degF")
    ax1.set_title("Heat-transfer uncertainty envelope")
    ax1.grid(True)
    ax1.legend(loc="upper left")
    fig.colorbar(sc, ax=ax1, label="Mach")

    explained_pct = 100 * pcaResult['explained'][:min(6, len(pcaResult['explained']))]
    ax2.bar(range(1, len(explained_pct) + 1), explained_pct)
    ax2.set_xlabel("Principal component")
    ax2.set_ylabel("Variance explained, %")
    ax2.set_title("SVD compression of design space")
    ax2.grid(True)

    plt.tight_layout()
    plt.savefig(os.path.join(outDir, "journal_design_guidelines.png"), dpi=220)
    plt.close()


def run_ht_journal_analysis(
    sweepMode="factorial",
    outDir="../outputs",
    makePlots=True,
    runAutoencoder=True,
    runRomOrderStudy=True,
    runMonteCarlo=True,
    diameter_um=812.8,
    tcType='N',
    nSamples=8000,
    sampleSeed=41
):
    if not os.path.exists(outDir):
        os.makedirs(outDir)

    cfg = ht_default_config()
    cfg['d_in'] = diameter_um / 25400.0
    cfg['Type'] = tcType

    data = ht_build_design_table(cfg, sweepMode, nSamples, sampleSeed)
    data.to_csv(os.path.join(outDir, "matlab_ht_design_table.csv"), index=False)
    print(f"Generated {len(data)} design points using {sweepMode} sweep.")

    pcaResult = ht_svd_analysis(data, outDir)

    romOrder = ht_pc_rom_order_study(data, outDir) if runRomOrderStudy else None
    aeResult = ht_autoencoder_compare(data, outDir) if runAutoencoder else None
    mcResult = ht_monte_carlo_uncertainty(outDir, 8000) if runMonteCarlo else None

    if makePlots:
        ht_plot_design_guidelines(data, pcaResult, outDir)

    return {
        "config": cfg,
        "data": data,
        "pca": pcaResult,
        "romOrder": romOrder,
        "autoencoder": aeResult,
        "monteCarlo": mcResult
    }