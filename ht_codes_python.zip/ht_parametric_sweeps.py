# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 21:17:16 2026

@author: laksh
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

# Import main function from previous script
from ht_journal_analysis import run_ht_journal_analysis


def quadratic_features_local(Z):
    """Generates degree-2 polynomial (quadratic) feature combinations."""
    cols = [np.ones((Z.shape[0], 1)), Z]
    for i in range(Z.shape[1]):
        for j in range(i, Z.shape[1]):
            cols.append((Z[:, i] * Z[:, j])[:, np.newaxis])
    return np.hstack(cols)


def make_basic_plots(allData, outDir):
    """Generates diameter and thermocouple-type sensitivity plots."""
    caseRows = allData[
        (allData['Stage'] == 'TIT') &
        (allData['L_over_d'].isin([20, 40])) &
        (np.abs(allData['Mach'] - 0.5) < 1e-9) &
        (allData['w'] == 0.80) &
        (allData['x'] == 0.65)
    ].copy()

    # Plot 1: Diameter Effect
    plt.figure(figsize=(7.5, 5.2))
    diametersToPlot = [12, 25, 50, 90, 150, 250, 813]
    for d in diametersToPlot:
        rows = caseRows[
            (caseRows['Type'] == 'N') &
            (np.abs(caseRows['d_um'] - d) < 1e-9) &
            (caseRows['L_over_d'] == 20)
        ]
        plt.plot(rows['Tj_degF'], rows['WorstCaseCorrected_degF'], '-o', label=f"{d:.0f} µm")

    plt.grid(False)
    plt.xlabel('TIT junction temperature, degF')
    plt.ylabel(r'$U_{HT}$, degF')
    plt.title('Effect of wire diameter, Type N, M=0.5, L/d=20')
    plt.legend(loc='upper left')
    plt.tight_layout()
    plt.savefig(os.path.join(outDir, "matlab_diameter_effect_uncertainty.png"), dpi=220)
    plt.close()

    # Plot 2: Thermocouple Type Comparison across L/d ratios
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 5.2), sharey=True)
    for idx, ld in enumerate([20, 40]):
        ax = axes[idx]
        for typ in ['E', 'J', 'K', 'N']:
            rows = caseRows[
                (caseRows['Type'] == typ) &
                (np.abs(caseRows['d_um'] - 90) < 1e-9) &
                (caseRows['L_over_d'] == ld)
            ]
            ax.plot(rows['Tj_degF'], rows['WorstCaseCorrected_degF'], '-o', label=f'Type {typ}')

        ax.grid(False)
        ax.set_xlabel('TIT junction temperature, degF')
        if idx == 0:
            ax.set_ylabel(r'$U_{HT}$, degF')
        ax.set_title(f'd=90 µm, M=0.5, L/d={ld}')
        ax.legend(loc='upper left')

    fig.suptitle(r'Thermocouple type comparison: $U_{HT}$ only')
    plt.tight_layout()
    plt.savefig(os.path.join(outDir, "matlab_thermocouple_type_uncertainty.png"), dpi=220)
    plt.close()


def make_pc_order_study(allData, outDir):
    """Executes the expanded PCA/SVD surrogate order study on all collected sweep data."""
    vars_list = [
        "Tj_degF", "Mach", "L_over_d", "w", "x", "Pflow_psia",
        "d_um", "Re", "Nu", "hc", "ks", "Ti_degF"
    ]
    X = allData[vars_list].values
    types = ['E', 'J', 'K', 'N']

    # One-hot encoding for TC types
    oneHot = np.zeros((len(allData), len(types)))
    for i, t in enumerate(types):
        oneHot[:, i] = (allData['Type'] == t).astype(float)

    X = np.hstack([X, oneHot])
    mu = np.mean(X, axis=0)
    sig = np.std(X, axis=0, ddof=0)
    sig[sig == 0] = 1.0
    Z = (X - mu) / sig

    Y = allData['WorstCaseCorrected_degF'].values
    Ylog = np.log10(Y + 1e-6)

    np.random.seed(17)
    idx = np.random.permutation(Z.shape[0])
    nTrain = int(0.75 * len(idx))
    train, test = idx[:nTrain], idx[nTrain:]

    pca = PCA()
    pca.fit(Z[train])
    explained = pca.explained_variance_ratio_
    V = pca.components_.T

    rows = []
    max_pcs = min(10, Z.shape[1])
    for nPC in range(2, max_pcs + 1):
        Ztr = Z[train] @ V[:, :nPC]
        Zte = Z[test] @ V[:, :nPC]
        PhiTr = quadratic_features_local(Ztr)
        PhiTe = quadratic_features_local(Zte)

        beta, _, _, _ = np.linalg.lstsq(PhiTr, Ylog[train], rcond=None)
        predLog = PhiTe @ beta
        pred = 10.0**predLog - 1e-6

        rmseLog = np.sqrt(np.mean((predLog - Ylog[test])**2))
        r2 = 1.0 - np.sum((Ylog[test] - predLog)**2) / np.sum((Ylog[test] - np.mean(Ylog[test]))**2)
        rel = np.abs(pred - Y[test]) / np.maximum(Y[test], 1e-6)

        rows.append([
            nPC,
            np.sum(explained[:nPC]),
            rmseLog,
            r2,
            np.median(rel),
            np.quantile(rel, 0.95)
        ])

    romTable = pd.DataFrame(rows, columns=[
        'n_pc', 'variance_retained_train', 'rmse_log10', 'r2_log10',
        'median_relative_error', 'p95_relative_error'
    ])
    romTable.to_csv(os.path.join(outDir, "matlab_parametric_pc_rom_order_sweep.csv"), index=False)

    plt.figure(figsize=(7.5, 5.2))
    plt.plot(romTable['n_pc'], romTable['rmse_log10'], '-o', linewidth=1.8)
    plt.grid(False)
    plt.xlabel('Number of retained PCs')
    plt.ylabel(r'RMSE in $\log_{10}(U_{HT})$')
    plt.title('Expanded PCA/SVD surrogate order study')
    plt.tight_layout()
    plt.savefig(os.path.join(outDir, "matlab_parametric_pc_rom_order_sweep.png"), dpi=220)
    plt.close()


def run_ht_parametric_sweeps():
    """Main sweep driver reproducing the MATLAB parameter grid study."""
    outDir = "../outputs/matlab_parametric"
    if not os.path.exists(outDir):
        os.makedirs(outDir)

    diameters_um = [12, 25, 50, 90, 125, 150, 250, 813]
    tcTypes = ['E', 'J', 'K', 'N']
    data_list = []

    for typ in tcTypes:
        for d in diameters_um:
            r = run_ht_journal_analysis(
                sweepMode="factorial",
                diameter_um=d,
                tcType=typ,
                outDir=outDir,
                makePlots=False,
                runAutoencoder=False,
                runRomOrderStudy=False,
                runMonteCarlo=False
            )
            data = r['data'].copy()
            data['d_um'] = d
            data['Type'] = typ
            data_list.append(data)

    allData = pd.concat(data_list, ignore_index=True)
    allData.to_csv(os.path.join(outDir, "matlab_ht_diameter_type_design.csv"), index=False)

    make_basic_plots(allData, outDir)
    make_pc_order_study(allData, outDir)

    return allData